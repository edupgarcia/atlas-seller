


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


CREATE EXTENSION IF NOT EXISTS "pg_cron" WITH SCHEMA "pg_catalog";






CREATE EXTENSION IF NOT EXISTS "pg_net" WITH SCHEMA "extensions";






COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE OR REPLACE FUNCTION "public"."fn_protect_cost_product"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND NEW.cost_product IS NULL THEN
    NEW.cost_product := OLD.cost_product;  -- NULL não apaga custo existente
  END IF;

  NEW.cost_status := CASE WHEN COALESCE(NEW.cost_product,0) > 0
                          THEN 'ok' ELSE 'missing' END;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."fn_protect_cost_product"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_max_created_after"() RETURNS "text"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  max_date TIMESTAMPTZ;
BEGIN
  SELECT MAX(created_time) INTO max_date FROM orders_amazon;
  IF max_date IS NULL THEN
    RETURN NULL;
  END IF;
  RETURN to_char(max_date - interval '1 day', 'YYYY-MM-DD') || 'T00:00:00Z';
END;
$$;


ALTER FUNCTION "public"."get_max_created_after"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_pending_fee_estimates"() RETURNS TABLE("seller_sku" "text", "listing_price" numeric)
    LANGUAGE "sql"
    AS $$
  SELECT DISTINCT dss.seller_sku::text, foi.item_price_amount::numeric
  FROM fact_order_item foi
  LEFT JOIN dim_seller_sku dss ON foi.seller_sku_id = dss.id
  WHERE dss.seller_sku IS NOT NULL
    AND foi.item_price_amount IS NOT NULL
    AND NOT EXISTS (
      SELECT 1 FROM marketplace_fee_estimates mfe
      WHERE mfe.seller_sku = dss.seller_sku
        AND mfe.listing_price = foi.item_price_amount
        AND mfe.status = 'success'
    );
$$;


ALTER FUNCTION "public"."get_pending_fee_estimates"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_login_blocked"("p_key" "text", "p_max" integer, "p_window_seconds" integer) RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  select exists (
    select 1 from public.login_attempts
    where key = p_key
      and failures >= p_max
      and window_start >= now() - make_interval(secs => p_window_seconds)
  );
$$;


ALTER FUNCTION "public"."is_login_blocked"("p_key" "text", "p_max" integer, "p_window_seconds" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."load_fact_order"() RETURNS integer
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    rows_processed INTEGER;
BEGIN

    INSERT INTO fact_order
    (
        amazon_order_id,
        marketplace_id,

        purchase_date,
        order_date,
        last_update_date,

        order_status,

        fulfillment_channel,
        sales_channel,

        order_total_amount,
        order_total_currency,

        number_of_items_shipped,
        number_of_items_unshipped,

        is_business_order,

        source_system,
        source_created_at,

        created_at,
        updated_at
    )

    SELECT

        amazon_order_id,
        marketplace_id,

        purchase_date,
        purchase_date::DATE,
        last_update_date,

        order_status,

        fulfillment_channel,
        sales_channel,

        order_total_amount,
        order_total_currency,

        number_of_items_shipped,
        number_of_items_unshipped,

        is_business_order,

        'AMAZON_SP_API',
        extraction_date,

        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP

    FROM stg_orders_amazon

    WHERE processed = FALSE


    ON CONFLICT (amazon_order_id)

    DO UPDATE SET

        order_status = EXCLUDED.order_status,

        last_update_date = EXCLUDED.last_update_date,

        fulfillment_channel =
            EXCLUDED.fulfillment_channel,

        sales_channel =
            EXCLUDED.sales_channel,

        order_total_amount =
            EXCLUDED.order_total_amount,

        order_total_currency =
            EXCLUDED.order_total_currency,

        number_of_items_shipped =
            EXCLUDED.number_of_items_shipped,

        number_of_items_unshipped =
            EXCLUDED.number_of_items_unshipped,

        is_business_order =
            EXCLUDED.is_business_order,

        updated_at = CURRENT_TIMESTAMP;


    GET DIAGNOSTICS rows_processed = ROW_COUNT;


    UPDATE stg_orders_amazon

    SET
        processed = TRUE,
        processed_date = CURRENT_TIMESTAMP

    WHERE processed = FALSE;


    RETURN rows_processed;

END;
$$;


ALTER FUNCTION "public"."load_fact_order"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."load_fact_order_item"() RETURNS integer
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    rows_processed INTEGER;
BEGIN

    INSERT INTO fact_order_item
    (
        order_id,
        amazon_order_id,
        order_item_id,

        seller_sku_id,

        asin,
        seller_sku,
        item_title,

        quantity_ordered,

        item_price_amount,
        item_tax_amount,
        promotion_discount_amount,

        item_revenue,

        currency,

        fulfillment_channel,

        source_system,

        created_at,
        updated_at
    )

    SELECT
        fo.id,

        s.amazon_order_id,
        s.order_item_id,

        NULL,

        s.asin,
        s.seller_sku,
        s.title,

        s.quantity_ordered,

        s.item_price_amount,
        s.item_tax_amount,
        s.promotion_discount_amount,

        COALESCE(s.item_price_amount, 0)
        + COALESCE(s.item_tax_amount, 0)
        - COALESCE(s.promotion_discount_amount, 0),

        s.item_price_currency,

        s.fulfillment_channel,

        'AMAZON_SP_API',

        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP

    FROM stg_order_items_amazon s

    INNER JOIN fact_order fo
        ON fo.amazon_order_id = s.amazon_order_id

    WHERE s.processed = FALSE
      AND s.order_item_id IS NOT NULL
      AND s.order_item_id <> s.amazon_order_id
      AND NULLIF(TRIM(s.seller_sku), '') IS NOT NULL

    ON CONFLICT
    (
        amazon_order_id,
        order_item_id
    )

    DO UPDATE SET

        seller_sku = EXCLUDED.seller_sku,

        item_title = EXCLUDED.item_title,

        quantity_ordered = EXCLUDED.quantity_ordered,

        item_price_amount = EXCLUDED.item_price_amount,

        item_tax_amount = EXCLUDED.item_tax_amount,

        promotion_discount_amount = EXCLUDED.promotion_discount_amount,

        item_revenue = EXCLUDED.item_revenue,

        updated_at = CURRENT_TIMESTAMP;


    GET DIAGNOSTICS rows_processed = ROW_COUNT;


    UPDATE stg_order_items_amazon

    SET
        processed = TRUE,
        processed_date = CURRENT_TIMESTAMP

    WHERE processed = FALSE;


    RETURN rows_processed;

END;
$$;


ALTER FUNCTION "public"."load_fact_order_item"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."register_login_failure"("p_key" "text", "p_window_seconds" integer) RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare v integer;
begin
  insert into public.login_attempts as la (key, failures, window_start)
  values (p_key, 1, now())
  on conflict (key) do update
    set failures = case when la.window_start < now() - make_interval(secs => p_window_seconds)
                        then 1 else la.failures + 1 end,
        window_start = case when la.window_start < now() - make_interval(secs => p_window_seconds)
                            then now() else la.window_start end
  returning failures into v;
  return v;
end $$;


ALTER FUNCTION "public"."register_login_failure"("p_key" "text", "p_window_seconds" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."reprocess_costs"("p_sku" "text", "p_from" timestamp with time zone, "p_to" timestamp with time zone, "p_account_id" "uuid" DEFAULT NULL::"uuid") RETURNS TABLE("sku" "text", "orders_updated" bigint, "cost_before" numeric, "cost_after" numeric)
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_sku_id BIGINT;
  v_cost_atual NUMERIC;
BEGIN
  -- Busca o registro canônico do SKU (prioriza o da conta informada, depois qualquer um com conta)
  SELECT d.id, d.cost_product INTO v_sku_id, v_cost_atual
  FROM dim_seller_sku d
  WHERE d.seller_sku = p_sku
    AND (p_account_id IS NULL OR d.marketplace_account_id = p_account_id)
  ORDER BY d.marketplace_account_id NULLS LAST, d.id DESC
  LIMIT 1;

  IF NOT FOUND OR v_sku_id IS NULL THEN
    RETURN QUERY SELECT p_sku, 0::BIGINT, 0::NUMERIC, 0::NUMERIC;
    RETURN;
  END IF;

  RETURN QUERY
  WITH updated AS (
    UPDATE fact_order_item foi
    SET cost_product = v_cost_atual,
        cost_status = 'ok',
        updated_at = now()
    FROM fact_order fo
    WHERE foi.amazon_order_id::text = fo.amazon_order_id::text
      AND foi.seller_sku_id = v_sku_id
      AND fo.purchase_date >= p_from
      AND fo.purchase_date < (p_to + INTERVAL '1 day')
      AND (foi.cost_product IS DISTINCT FROM v_cost_atual OR foi.cost_status IS DISTINCT FROM 'ok')
    RETURNING foi.cost_product AS novo_custo
  )
  SELECT p_sku, COUNT(*)::BIGINT, v_cost_atual, v_cost_atual
  FROM updated;
END;
$$;


ALTER FUNCTION "public"."reprocess_costs"("p_sku" "text", "p_from" timestamp with time zone, "p_to" timestamp with time zone, "p_account_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."trigger_estimate_fees"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_anon_key TEXT;
BEGIN
  -- Pega a chave da tabela de config
  SELECT value INTO v_anon_key
  FROM app_config
  WHERE key = 'supabase_anon_key';

  IF v_anon_key IS NULL THEN
    RAISE WARNING 'app_config.supabase_anon_key não configurada';
    RETURN NEW;
  END IF;

  -- Chamada assíncrona para a Edge Function (fire-and-forget)
  PERFORM net.http_post(
    url := 'https://omvtqftgbkdthgfypjlx.supabase.co/functions/v1/amazon-orders-fee-estimated',
    headers := jsonb_build_object(
      'Authorization', 'Bearer ' || v_anon_key,
      'Content-Type', 'application/json'
    ),
    body := jsonb_build_object('amazon_order_id', NEW.amazon_order_id)
  );

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."trigger_estimate_fees"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."upsert_orders_batch"("p_orders" "jsonb") RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  inserted INTEGER := 0;
  item JSONB;
BEGIN
  FOR item IN SELECT * FROM jsonb_array_elements(p_orders)
  LOOP
    INSERT INTO orders_amazon (
      order_id, created_time, last_updated_time, programs, marketplace_id,
      marketplace_name, channel_name, condition, amount, currency_code,
      asin, seller_sku, title, order_item_id, quantity_ordered,
      alias_id, alias_type, fulfillment_channel, canal_logistica
    ) VALUES (
      item->>'order_id',
      NULLIF(item->>'created_time', '')::TIMESTAMPTZ,
      NULLIF(item->>'last_updated_time', '')::TIMESTAMPTZ,
      item->>'programs',
      item->>'marketplace_id',
      item->>'marketplace_name',
      item->>'channel_name',
      item->>'condition',
      (item->>'amount')::NUMERIC,
      item->>'currency_code',
      item->>'asin',
      item->>'seller_sku',
      item->>'title',
      item->>'order_item_id',
      (item->>'quantity_ordered')::INTEGER,
      item->>'alias_id',
      item->>'alias_type',
      item->>'fulfillment_channel',
      item->>'canal_logistica'
    )
    ON CONFLICT (order_item_id) DO UPDATE SET
      order_id = EXCLUDED.order_id,
      created_time = EXCLUDED.created_time,
      last_updated_time = EXCLUDED.last_updated_time,
      programs = EXCLUDED.programs,
      marketplace_id = EXCLUDED.marketplace_id,
      marketplace_name = EXCLUDED.marketplace_name,
      channel_name = EXCLUDED.channel_name,
      condition = EXCLUDED.condition,
      amount = EXCLUDED.amount,
      currency_code = EXCLUDED.currency_code,
      asin = EXCLUDED.asin,
      seller_sku = EXCLUDED.seller_sku,
      title = EXCLUDED.title,
      quantity_ordered = EXCLUDED.quantity_ordered,
      alias_id = EXCLUDED.alias_id,
      alias_type = EXCLUDED.alias_type,
      fulfillment_channel = EXCLUDED.fulfillment_channel,
      canal_logistica = EXCLUDED.canal_logistica;

    inserted := inserted + 1;
  END LOOP;
  RETURN inserted;
END;
$$;


ALTER FUNCTION "public"."upsert_orders_batch"("p_orders" "jsonb") OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."account_sku_costs" (
    "account_id" "text" NOT NULL,
    "seller_sku" "text" NOT NULL,
    "cost_product" numeric NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "account_sku_costs_cost_product_check" CHECK (("cost_product" >= (0)::numeric))
);


ALTER TABLE "public"."account_sku_costs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."amazon_orders_raw" (
    "id" bigint NOT NULL,
    "account_id" "uuid" NOT NULL,
    "amazon_order_id" character varying(25) NOT NULL,
    "last_update_date" timestamp with time zone,
    "purchase_date" timestamp with time zone,
    "payload" "jsonb" NOT NULL,
    "payload_hash" character varying(64),
    "received_at" timestamp with time zone DEFAULT "now"(),
    "processed" boolean DEFAULT false,
    "processed_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "source_api" character varying(50) DEFAULT 'orders-2026-01-01'::character varying NOT NULL,
    "api_source_id" smallint
);


ALTER TABLE "public"."amazon_orders_raw" OWNER TO "postgres";


ALTER TABLE "public"."amazon_orders_raw" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."amazon_orders_raw_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."api_sources" (
    "id" smallint NOT NULL,
    "service" character varying(30) NOT NULL,
    "version" character varying(20) NOT NULL,
    "description" character varying(100),
    "active" boolean DEFAULT true
);


ALTER TABLE "public"."api_sources" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."api_sources_id_seq"
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."api_sources_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."api_sources_id_seq" OWNED BY "public"."api_sources"."id";



CREATE TABLE IF NOT EXISTS "public"."app_config" (
    "key" "text" NOT NULL,
    "value" "text" NOT NULL
);


ALTER TABLE "public"."app_config" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."bling_accounts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "seller_id" "uuid" NOT NULL,
    "access_token" "text" NOT NULL,
    "refresh_token" "text" NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."bling_accounts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."bridge_seller_sku_identifier" (
    "id" bigint NOT NULL,
    "seller_sku_id" bigint NOT NULL,
    "marketplace" character varying(50) NOT NULL,
    "identifier_type" character varying(50) NOT NULL,
    "identifier_value" character varying(150) NOT NULL,
    "is_active" boolean DEFAULT true,
    "valid_from" "date" DEFAULT CURRENT_DATE,
    "valid_to" "date",
    "created_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "public"."bridge_seller_sku_identifier" OWNER TO "postgres";


ALTER TABLE "public"."bridge_seller_sku_identifier" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."bridge_seller_sku_identifier_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."dim_date" (
    "date_key" "date" NOT NULL,
    "year" integer NOT NULL,
    "quarter" integer NOT NULL,
    "month" integer NOT NULL,
    "month_name" character varying(20),
    "week_of_year" integer,
    "day" integer NOT NULL,
    "day_of_week" integer,
    "day_name" character varying(20),
    "is_weekend" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "public"."dim_date" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."dim_financial_category" (
    "id" bigint NOT NULL,
    "api_event_type" character varying(100) NOT NULL,
    "api_charge_type" character varying(100) NOT NULL,
    "category_code" character varying(50) NOT NULL,
    "category_name" character varying(100) NOT NULL,
    "description" "text",
    "is_active" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "public"."dim_financial_category" OWNER TO "postgres";


ALTER TABLE "public"."dim_financial_category" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."dim_financial_category_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."dim_seller_sku" (
    "id" bigint NOT NULL,
    "seller_sku" character varying(100) NOT NULL,
    "asin" character varying(20),
    "fnsku" character varying(50),
    "catalog_product_id" character varying(100),
    "product_name" character varying(255),
    "brand" character varying(100),
    "category" character varying(100),
    "product_group" character varying(100),
    "status" character varying(30) DEFAULT 'ACTIVE'::character varying,
    "launch_date" "date",
    "discontinued_date" "date",
    "cost_product" numeric(12,2),
    "cost_import" numeric(12,2),
    "cost_freight" numeric(12,2),
    "cost_total" numeric(12,2),
    "tax_regime" character varying(50),
    "tax_percentage" numeric(5,2),
    "fulfillment_type" character varying(20),
    "supplier" character varying(150),
    "weight" numeric(10,3),
    "length" numeric(10,2),
    "width" numeric(10,2),
    "height" numeric(10,2),
    "target_margin" numeric(5,2),
    "minimum_margin" numeric(5,2),
    "price_target" numeric(12,2),
    "created_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updated_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "marketplace_account_id" "uuid"
);


ALTER TABLE "public"."dim_seller_sku" OWNER TO "postgres";


ALTER TABLE "public"."dim_seller_sku" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."dim_seller_sku_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."fact_financial_transaction" (
    "id" bigint NOT NULL,
    "financial_event_id" character varying(100) NOT NULL,
    "amazon_order_id" character varying(50),
    "seller_order_id" character varying(100),
    "event_type" character varying(100) NOT NULL,
    "charge_or_fee_type" character varying(150) NOT NULL,
    "seller_sku_id" bigint,
    "financial_category_id" bigint,
    "asin" character varying(20),
    "seller_sku" character varying(100),
    "transaction_date" timestamp with time zone NOT NULL,
    "amount" numeric(12,2) NOT NULL,
    "currency" character varying(10) DEFAULT 'BRL'::character varying,
    "quantity" integer,
    "source_system" character varying(50) DEFAULT 'AMAZON_SP_API'::character varying,
    "source_created_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "transaction_date_key" "date"
);


ALTER TABLE "public"."fact_financial_transaction" OWNER TO "postgres";


ALTER TABLE "public"."fact_financial_transaction" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."fact_financial_transaction_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."fact_order" (
    "id" bigint NOT NULL,
    "amazon_order_id" character varying(50) NOT NULL,
    "marketplace_id" character varying(50),
    "purchase_date" timestamp with time zone NOT NULL,
    "order_date" "date" NOT NULL,
    "last_update_date" timestamp with time zone,
    "order_status" character varying(50),
    "fulfillment_channel" character varying(20),
    "sales_channel" character varying(100),
    "order_total_amount" numeric(12,2),
    "order_total_currency" character varying(10),
    "number_of_items" integer,
    "number_of_items_shipped" integer,
    "number_of_items_unshipped" integer,
    "is_business_order" boolean DEFAULT false,
    "source_system" character varying(50) DEFAULT 'AMAZON_SP_API'::character varying,
    "source_created_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "marketplace_account_id" "uuid" NOT NULL,
    "account_id" "uuid"
);


ALTER TABLE "public"."fact_order" OWNER TO "postgres";


ALTER TABLE "public"."fact_order" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."fact_order_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."fact_order_item" (
    "id" bigint NOT NULL,
    "order_id" bigint NOT NULL,
    "amazon_order_id" character varying(50) NOT NULL,
    "order_item_id" character varying(100),
    "seller_sku_id" bigint,
    "quantity_ordered" integer NOT NULL,
    "item_price_amount" numeric(12,2),
    "item_tax_amount" numeric(12,2),
    "promotion_discount_amount" numeric(12,2),
    "item_revenue" numeric(12,2),
    "currency" character varying(10),
    "fulfillment_channel" character varying(20),
    "source_system" character varying(50) DEFAULT 'AMAZON_SP_API'::character varying,
    "created_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updated_at" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "account_id" "uuid",
    "cost_product" numeric,
    "cost_status" character varying DEFAULT 'pending'::character varying
);


ALTER TABLE "public"."fact_order_item" OWNER TO "postgres";


ALTER TABLE "public"."fact_order_item" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."fact_order_item_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."financial_checkpoint" (
    "id" integer DEFAULT 1 NOT NULL,
    "last_processed_date" timestamp with time zone,
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."financial_checkpoint" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."financial_events" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "amazon_order_id" "text",
    "posted_date" timestamp with time zone,
    "seller_sku" "text",
    "event_type" "text",
    "charge_or_fee_type" "text",
    "amount" numeric DEFAULT 0,
    "currency" "text" DEFAULT 'BRL'::"text",
    "shipment_id" "text",
    "raw_data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "marketplace_account_id" "uuid",
    "account_id" "uuid"
);


ALTER TABLE "public"."financial_events" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."integration_sources" (
    "id" smallint NOT NULL,
    "provider" character varying(30) NOT NULL,
    "service" character varying(30) NOT NULL,
    "version" character varying(20) NOT NULL,
    "description" character varying(100),
    "active" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."integration_sources" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."integration_sources_id_seq"
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."integration_sources_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."integration_sources_id_seq" OWNED BY "public"."integration_sources"."id";



CREATE TABLE IF NOT EXISTS "public"."login_attempts" (
    "key" "text" NOT NULL,
    "failures" integer DEFAULT 0 NOT NULL,
    "window_start" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."login_attempts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."marketplace_accounts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "seller_name" character varying(100) NOT NULL,
    "marketplace_provider" character varying(30) NOT NULL,
    "marketplace_region" character varying(10),
    "marketplace_id" character varying(30),
    "merchant_id" character varying(50),
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "refresh_token" "text" NOT NULL,
    "status" smallint DEFAULT 1,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_orders_sync" timestamp with time zone,
    "last_financial_sync" timestamp with time zone,
    "spapi_region" character varying DEFAULT 'na'::character varying,
    "auto_sync" boolean DEFAULT true,
    "last_sync_at" timestamp with time zone,
    "user_id" "uuid",
    "amazon_seller_id" "text",
    "seller_id" "uuid"
);


ALTER TABLE "public"."marketplace_accounts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."marketplace_fee_estimates" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "seller_sku" "text" NOT NULL,
    "marketplace_id" "text" DEFAULT 'A2Q3Y263D00KWC'::"text" NOT NULL,
    "listing_price" numeric(12,2) NOT NULL,
    "is_fba" boolean NOT NULL,
    "referral_fee" numeric(12,4) DEFAULT 0,
    "fba_fulfillment_fee" numeric(12,4) DEFAULT 0,
    "variable_closing_fee" numeric(12,4) DEFAULT 0,
    "total_fees" numeric(12,4) DEFAULT 0,
    "estimated_at" timestamp with time zone DEFAULT "now"(),
    "status" "text" DEFAULT 'success'::"text",
    "raw_response" "jsonb",
    "mfn_postage_fee" numeric DEFAULT 0
);


ALTER TABLE "public"."marketplace_fee_estimates" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ml_accounts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "ml_user_id" bigint NOT NULL,
    "nickname" "text",
    "access_token" "text" NOT NULL,
    "refresh_token" "text" NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    "scope" "text",
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "last_sync_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."ml_accounts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ml_oauth_states" (
    "state" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:10:00'::interval) NOT NULL
);


ALTER TABLE "public"."ml_oauth_states" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."orders_amazon" (
    "id" integer NOT NULL,
    "order_id" "text" NOT NULL,
    "order_item_id" "text" NOT NULL,
    "created_time" timestamp with time zone,
    "last_updated_time" timestamp with time zone,
    "programs" "text",
    "marketplace_id" "text",
    "marketplace_name" "text",
    "channel_name" "text",
    "condition" "text",
    "amount" numeric(12,2),
    "currency_code" "text",
    "asin" "text",
    "seller_sku" "text",
    "title" "text",
    "quantity_ordered" integer,
    "alias_id" "text",
    "alias_type" "text",
    "fulfillment_channel" "text",
    "canal_logistica" "text",
    "raw_json" "jsonb",
    "ingested_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."orders_amazon" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."orders_amazon_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."orders_amazon_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."orders_amazon_id_seq" OWNED BY "public"."orders_amazon"."id";



CREATE TABLE IF NOT EXISTS "public"."orders_checkpoint" (
    "id" integer DEFAULT 1 NOT NULL,
    "last_processed_date" timestamp with time zone,
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."orders_checkpoint" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."sellers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "company_name" character varying(120),
    "document" character varying(20),
    "email" character varying(120),
    "status" smallint DEFAULT 1,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "password" "text",
    "name" "text",
    "marketplace_account_id" "text"
);


ALTER TABLE "public"."sellers" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."stg_financial_transactions_amazon" (
    "id" bigint NOT NULL,
    "amazon_order_id" character varying(50),
    "seller_order_id" character varying(100),
    "financial_event_id" character varying(100),
    "event_type" character varying(100),
    "event_date" timestamp with time zone,
    "asin" character varying(20),
    "seller_sku" character varying(100),
    "quantity" integer,
    "amount" numeric(12,2),
    "currency" character varying(10),
    "extraction_date" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "extraction_batch_id" character varying(50),
    "raw_json" "jsonb",
    "processed" boolean DEFAULT false,
    "processed_date" timestamp with time zone
);


ALTER TABLE "public"."stg_financial_transactions_amazon" OWNER TO "postgres";


ALTER TABLE "public"."stg_financial_transactions_amazon" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."stg_financial_transactions_amazon_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."stg_order_items_amazon" (
    "id" bigint NOT NULL,
    "amazon_order_id" character varying(50) NOT NULL,
    "order_item_id" character varying(100),
    "asin" character varying(20),
    "seller_sku" character varying(100),
    "title" character varying(500),
    "quantity_ordered" integer,
    "item_price_amount" numeric(12,2),
    "item_price_currency" character varying(10),
    "item_tax_amount" numeric(12,2),
    "item_tax_currency" character varying(10),
    "promotion_discount_amount" numeric(12,2),
    "promotion_discount_currency" character varying(10),
    "condition_id" character varying(50),
    "fulfillment_channel" character varying(20),
    "is_gift" boolean DEFAULT false,
    "extraction_date" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "extraction_batch_id" character varying(50),
    "raw_json" "jsonb",
    "processed" boolean DEFAULT false,
    "processed_date" timestamp with time zone,
    "marketplace_account_id" "uuid"
);


ALTER TABLE "public"."stg_order_items_amazon" OWNER TO "postgres";


ALTER TABLE "public"."stg_order_items_amazon" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."stg_order_items_amazon_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."stg_order_items_mercadolivre" (
    "ml_account_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "order_id" bigint NOT NULL,
    "item_id" "text" NOT NULL,
    "variation_id" bigint DEFAULT 0 NOT NULL,
    "title" "text",
    "seller_sku" "text",
    "quantity" integer,
    "unit_price" numeric(14,2),
    "full_unit_price" numeric(14,2),
    "sale_fee" numeric(14,2),
    "currency_id" "text",
    "raw" "jsonb",
    "synced_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."stg_order_items_mercadolivre" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."stg_orders_amazon" (
    "id" bigint NOT NULL,
    "amazon_order_id" character varying(50) NOT NULL,
    "marketplace_id" character varying(50),
    "purchase_date" timestamp without time zone,
    "last_update_date" timestamp without time zone,
    "order_status" character varying(50),
    "fulfillment_channel" character varying(20),
    "sales_channel" character varying(50),
    "order_total_amount" numeric(12,2),
    "order_total_currency" character varying(10),
    "number_of_items_unshipped" integer,
    "number_of_items_shipped" integer,
    "buyer_country" character varying(10),
    "is_business_order" boolean DEFAULT false,
    "extraction_date" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "extraction_batch_id" character varying(50),
    "raw_json" "jsonb",
    "processed" boolean DEFAULT false,
    "processed_date" timestamp without time zone,
    "items_fetched" boolean DEFAULT false,
    "marketplace_account_id" "uuid"
);


ALTER TABLE "public"."stg_orders_amazon" OWNER TO "postgres";


ALTER TABLE "public"."stg_orders_amazon" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."stg_orders_amazon_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."stg_orders_mercadolivre" (
    "ml_account_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "order_id" bigint NOT NULL,
    "status" "text",
    "date_created" timestamp with time zone,
    "date_closed" timestamp with time zone,
    "date_last_updated" timestamp with time zone,
    "total_amount" numeric(14,2),
    "paid_amount" numeric(14,2),
    "currency_id" "text",
    "buyer_id" bigint,
    "shipping_id" bigint,
    "pack_id" bigint,
    "raw" "jsonb",
    "synced_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "ml_user_id" "text",
    "seller_id" "uuid",
    "marketplace_account_id" "uuid",
    "last_updated" timestamp with time zone,
    "tags" "jsonb",
    "order_items" "jsonb",
    "payments" "jsonb"
);


ALTER TABLE "public"."stg_orders_mercadolivre" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."sync_checkpoint" (
    "source" character varying(100) NOT NULL,
    "last_updated_after" timestamp with time zone,
    "last_execution_at" timestamp with time zone,
    "status" character varying(20) DEFAULT 'active'::character varying,
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "checkpoint_value" "text",
    "last_synced_at" timestamp with time zone
);


ALTER TABLE "public"."sync_checkpoint" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."sync_checkpoint_orders" (
    "account_id" "uuid" NOT NULL,
    "marketplace_provider" integer DEFAULT 1 NOT NULL,
    "last_checkpoint" timestamp with time zone,
    "last_sync_at" timestamp with time zone DEFAULT "now"(),
    "records_processed" integer DEFAULT 0,
    "status" character varying DEFAULT 'pending'::character varying
);


ALTER TABLE "public"."sync_checkpoint_orders" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."sync_execution" (
    "id" bigint NOT NULL,
    "account_id" "uuid" NOT NULL,
    "resource" character varying(30),
    "started_at" timestamp with time zone,
    "finished_at" timestamp with time zone,
    "status" smallint,
    "orders_found" integer,
    "rows_written" integer,
    "api_calls" integer,
    "retries" integer,
    "duration_ms" integer,
    "error_message" "text"
);


ALTER TABLE "public"."sync_execution" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."sync_execution_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."sync_execution_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."sync_execution_id_seq" OWNED BY "public"."sync_execution"."id";



CREATE OR REPLACE VIEW "public"."vw_net_marketplace_estimated" WITH ("security_invoker"='true') AS
 WITH "missing_orders" AS (
         SELECT "foi"."amazon_order_id",
            "d"."seller_sku",
            "d"."product_name",
            "fo"."purchase_date",
            "fo"."order_status",
            COALESCE("fo"."fulfillment_channel", "foi"."fulfillment_channel") AS "fulfillment_channel",
            "fo"."sales_channel",
            "fo"."account_id",
            "foi"."order_item_id",
            "foi"."quantity_ordered",
            "foi"."item_price_amount",
            "foi"."item_revenue",
            "foi"."promotion_discount_amount",
            COALESCE("foi"."cost_product", "d"."cost_product", (0)::numeric) AS "cost_product",
            "foi"."cost_status"
           FROM (("public"."fact_order_item" "foi"
             LEFT JOIN "public"."fact_order" "fo" ON ((("foi"."amazon_order_id")::"text" = ("fo"."amazon_order_id")::"text")))
             LEFT JOIN "public"."dim_seller_sku" "d" ON (("foi"."seller_sku_id" = "d"."id")))
          WHERE (NOT (EXISTS ( SELECT 1
                   FROM "public"."financial_events" "fe_1"
                  WHERE (("fe_1"."amazon_order_id" = ("foi"."amazon_order_id")::"text") AND ("fe_1"."event_type" = ANY (ARRAY['ItemCharge'::"text", 'ItemFee'::"text"]))))))
        ), "service_fees" AS (
         SELECT "fe_1"."amazon_order_id",
            "fe_1"."seller_sku",
            "sum"(
                CASE
                    WHEN ("fe_1"."charge_or_fee_type" = 'MFNPostageFee'::"text") THEN "fe_1"."amount"
                    ELSE (0)::numeric
                END) AS "mfn_postage_fee_actual",
            "sum"(
                CASE
                    WHEN ("fe_1"."charge_or_fee_type" = 'MFNShippingChargeback'::"text") THEN "fe_1"."amount"
                    ELSE (0)::numeric
                END) AS "mfn_shipping_chargeback"
           FROM "public"."financial_events" "fe_1"
          WHERE ("fe_1"."event_type" = 'ServiceFee'::"text")
          GROUP BY "fe_1"."amazon_order_id", "fe_1"."seller_sku"
        ), "last_mfn_fee" AS (
         SELECT DISTINCT ON ("fe_1"."seller_sku") "fe_1"."seller_sku",
            "fe_1"."amount" AS "mfn_postage_fee_hist"
           FROM "public"."financial_events" "fe_1"
          WHERE (("fe_1"."charge_or_fee_type" = 'MFNPostageFee'::"text") AND ("fe_1"."amount" <> (0)::numeric))
          ORDER BY "fe_1"."seller_sku", "fe_1"."posted_date" DESC
        ), "sp_api_fees" AS (
         SELECT DISTINCT ON ("mo"."order_item_id") "mo"."order_item_id",
            "mfe"."referral_fee",
            "mfe"."fba_fulfillment_fee",
            "mfe"."variable_closing_fee",
            "mfe"."mfn_postage_fee",
            "mfe"."total_fees",
            "mfe"."estimated_at"
           FROM ("missing_orders" "mo"
             LEFT JOIN LATERAL ( SELECT "mfe_1"."id",
                    "mfe_1"."seller_sku",
                    "mfe_1"."marketplace_id",
                    "mfe_1"."listing_price",
                    "mfe_1"."is_fba",
                    "mfe_1"."referral_fee",
                    "mfe_1"."fba_fulfillment_fee",
                    "mfe_1"."variable_closing_fee",
                    "mfe_1"."mfn_postage_fee",
                    "mfe_1"."total_fees",
                    "mfe_1"."estimated_at",
                    "mfe_1"."status",
                    "mfe_1"."raw_response"
                   FROM "public"."marketplace_fee_estimates" "mfe_1"
                  WHERE (("mfe_1"."seller_sku" = ("mo"."seller_sku")::"text") AND ("mfe_1"."listing_price" = "mo"."item_price_amount") AND ("mfe_1"."is_fba" = (("mo"."fulfillment_channel")::"text" = ANY (ARRAY['AFN'::"text", 'AMAZON'::"text"]))))
                  ORDER BY "mfe_1"."estimated_at" DESC
                 LIMIT 1) "mfe" ON (true))
        ), "hist_item" AS (
         SELECT "fe_1"."amazon_order_id",
            "fe_1"."seller_sku",
            "fe_1"."posted_date",
            "sum"(
                CASE
                    WHEN (("fe_1"."event_type" = 'ItemCharge'::"text") AND ("fe_1"."charge_or_fee_type" = 'Principal'::"text")) THEN "fe_1"."amount"
                    ELSE (0)::numeric
                END) AS "principal",
            "sum"(
                CASE
                    WHEN (("fe_1"."event_type" = 'ItemFee'::"text") AND ("fe_1"."charge_or_fee_type" = 'FBAPerUnitFulfillmentFee'::"text")) THEN "fe_1"."amount"
                    ELSE (0)::numeric
                END) AS "fba_fee",
            "sum"(
                CASE
                    WHEN (("fe_1"."event_type" = 'ItemFee'::"text") AND ("fe_1"."charge_or_fee_type" = 'Commission'::"text")) THEN "fe_1"."amount"
                    ELSE (0)::numeric
                END) AS "commission",
            "sum"(
                CASE
                    WHEN ("fe_1"."event_type" = 'ItemFee'::"text") THEN "fe_1"."amount"
                    ELSE (0)::numeric
                END) AS "total_fees",
            "sum"(
                CASE
                    WHEN (("fe_1"."event_type" = 'ItemCharge'::"text") AND ("fe_1"."charge_or_fee_type" = 'Tax'::"text")) THEN "fe_1"."amount"
                    ELSE (0)::numeric
                END) AS "tax"
           FROM "public"."financial_events" "fe_1"
          WHERE ("fe_1"."event_type" = ANY (ARRAY['ItemCharge'::"text", 'ItemFee'::"text"]))
          GROUP BY "fe_1"."amazon_order_id", "fe_1"."seller_sku", "fe_1"."posted_date"
        ), "sku_stats" AS (
         SELECT "hi"."seller_sku",
            "avg"("hi"."tax") AS "avg_tax",
            "sum"("hi"."commission") AS "sum_commission",
            "sum"("hi"."principal") AS "sum_principal",
            "count"(*) AS "sample_count"
           FROM "hist_item" "hi"
          GROUP BY "hi"."seller_sku"
        ), "last_fba_sku" AS (
         SELECT DISTINCT ON ("hi"."seller_sku") "hi"."seller_sku",
            "hi"."fba_fee",
            "hi"."posted_date"
           FROM "hist_item" "hi"
          WHERE (("hi"."fba_fee" IS NOT NULL) AND ("hi"."fba_fee" <> (0)::numeric))
          ORDER BY "hi"."seller_sku", "hi"."posted_date" DESC
        ), "fallback_estimates" AS (
         SELECT "mo"."amazon_order_id",
            "mo"."seller_sku",
            "mo"."product_name",
            "mo"."purchase_date",
            "mo"."order_status",
            "mo"."fulfillment_channel",
            "mo"."sales_channel",
            "mo"."account_id",
            "mo"."order_item_id",
            "mo"."quantity_ordered",
            "mo"."item_price_amount",
            "mo"."item_revenue",
            "mo"."promotion_discount_amount",
            "mo"."cost_product",
            "mo"."cost_status",
                CASE
                    WHEN (("ss"."sample_count" >= 3) AND ("ss"."sum_principal" <> (0)::numeric)) THEN (("ss"."sum_commission" / "ss"."sum_principal") * "mo"."item_price_amount")
                    ELSE (0)::numeric
                END AS "est_commission_hist",
            COALESCE("lfs"."fba_fee", (0)::numeric) AS "est_fba_fee_hist",
            COALESCE("ss"."avg_tax", (0)::numeric) AS "est_tax_hist",
            "sp"."referral_fee",
            "sp"."fba_fulfillment_fee",
            "sp"."variable_closing_fee",
            "sp"."mfn_postage_fee",
            "sp"."total_fees",
            COALESCE("sf"."mfn_postage_fee_actual", (0)::numeric) AS "mfn_postage_fee_actual",
            COALESCE("sf"."mfn_shipping_chargeback", (0)::numeric) AS "mfn_shipping_chargeback",
            COALESCE("lmf"."mfn_postage_fee_hist", (0)::numeric) AS "mfn_postage_fee_hist"
           FROM ((((("missing_orders" "mo"
             LEFT JOIN "sku_stats" "ss" ON ((("mo"."seller_sku")::"text" = "ss"."seller_sku")))
             LEFT JOIN "last_fba_sku" "lfs" ON ((("mo"."seller_sku")::"text" = "lfs"."seller_sku")))
             LEFT JOIN "sp_api_fees" "sp" ON ((("mo"."order_item_id")::"text" = ("sp"."order_item_id")::"text")))
             LEFT JOIN "service_fees" "sf" ON (((("mo"."amazon_order_id")::"text" = "sf"."amazon_order_id") AND (("mo"."seller_sku")::"text" = "sf"."seller_sku"))))
             LEFT JOIN "last_mfn_fee" "lmf" ON ((("mo"."seller_sku")::"text" = "lmf"."seller_sku")))
        ), "mfn_with_rule" AS (
         SELECT "fallback_estimates"."amazon_order_id",
            "fallback_estimates"."seller_sku",
            "fallback_estimates"."product_name",
            "fallback_estimates"."purchase_date",
            "fallback_estimates"."order_status",
            "fallback_estimates"."fulfillment_channel",
            "fallback_estimates"."sales_channel",
            "fallback_estimates"."account_id",
            "fallback_estimates"."order_item_id",
            "fallback_estimates"."quantity_ordered",
            "fallback_estimates"."item_price_amount",
            "fallback_estimates"."item_revenue",
            "fallback_estimates"."promotion_discount_amount",
            "fallback_estimates"."cost_product",
            "fallback_estimates"."cost_status",
            "fallback_estimates"."est_commission_hist",
            "fallback_estimates"."est_fba_fee_hist",
            "fallback_estimates"."est_tax_hist",
            "fallback_estimates"."referral_fee",
            "fallback_estimates"."fba_fulfillment_fee",
            "fallback_estimates"."variable_closing_fee",
            "fallback_estimates"."mfn_postage_fee",
            "fallback_estimates"."total_fees",
            "fallback_estimates"."mfn_postage_fee_actual",
            "fallback_estimates"."mfn_shipping_chargeback",
            "fallback_estimates"."mfn_postage_fee_hist",
            COALESCE(NULLIF("fallback_estimates"."mfn_postage_fee_actual", (0)::numeric), ("fallback_estimates"."mfn_postage_fee" * ("fallback_estimates"."quantity_ordered")::numeric), NULLIF(("fallback_estimates"."mfn_postage_fee_hist" * ("fallback_estimates"."quantity_ordered")::numeric), (0)::numeric),
                CASE
                    WHEN ((("fallback_estimates"."fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("fallback_estimates"."item_price_amount" / (NULLIF("fallback_estimates"."quantity_ordered", 0))::numeric) <= 30.00)) THEN ('-4.50'::numeric * ("fallback_estimates"."quantity_ordered")::numeric)
                    WHEN ((("fallback_estimates"."fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("fallback_estimates"."item_price_amount" / (NULLIF("fallback_estimates"."quantity_ordered", 0))::numeric) <= 79.00)) THEN ('-6.75'::numeric * ("fallback_estimates"."quantity_ordered")::numeric)
                    ELSE (0)::numeric
                END) AS "mfn_postage_fee_calculado"
           FROM "fallback_estimates"
        )
 SELECT "amazon_order_id",
    "seller_sku",
    "product_name",
    NULL::timestamp with time zone AS "posted_date",
    "purchase_date" AS "order_purchase_date",
    "order_status",
    "fulfillment_channel" AS "order_fulfillment_channel",
    "sales_channel",
    "account_id",
    "order_item_id",
    "quantity_ordered",
    "item_price_amount",
    "item_revenue",
    (COALESCE("promotion_discount_amount", (0)::numeric) * ("quantity_ordered")::numeric) AS "promotion_discount",
    "cost_product",
    "cost_status",
    ("item_price_amount" * ("quantity_ordered")::numeric) AS "principal",
    (0)::numeric AS "shipping_charge",
    ("est_tax_hist" * ("quantity_ordered")::numeric) AS "tax",
    (COALESCE("fba_fulfillment_fee", "est_fba_fee_hist", (0)::numeric) * ("quantity_ordered")::numeric) AS "fba_fee",
    (COALESCE("referral_fee", "est_commission_hist", (0)::numeric) * ("quantity_ordered")::numeric) AS "commission",
    (((COALESCE("referral_fee", "est_commission_hist", (0)::numeric) * ("quantity_ordered")::numeric) + (COALESCE("fba_fulfillment_fee", "est_fba_fee_hist", (0)::numeric) * ("quantity_ordered")::numeric)) + "mfn_postage_fee_calculado") AS "total_fees",
    "mfn_postage_fee_calculado" AS "mfn_postage_fee",
    "mfn_shipping_chargeback",
    (0)::numeric AS "total_service_fees",
    ((((("item_price_amount" * ("quantity_ordered")::numeric) + (COALESCE("referral_fee", "est_commission_hist", (0)::numeric) * ("quantity_ordered")::numeric)) + (COALESCE("fba_fulfillment_fee", "est_fba_fee_hist", (0)::numeric) * ("quantity_ordered")::numeric)) + "mfn_postage_fee_calculado") - (COALESCE("promotion_discount_amount", (0)::numeric) * ("quantity_ordered")::numeric)) AS "net_revenue",
    (((((("item_price_amount" * ("quantity_ordered")::numeric) + (COALESCE("referral_fee", "est_commission_hist", (0)::numeric) * ("quantity_ordered")::numeric)) + (COALESCE("fba_fulfillment_fee", "est_fba_fee_hist", (0)::numeric) * ("quantity_ordered")::numeric)) + "mfn_postage_fee_calculado") - (COALESCE("promotion_discount_amount", (0)::numeric) * ("quantity_ordered")::numeric)) - (COALESCE("cost_product", (0)::numeric) * ("quantity_ordered")::numeric)) AS "gross_profit",
        CASE
            WHEN ("referral_fee" IS NOT NULL) THEN 'sp_api'::"text"
            ELSE 'historical'::"text"
        END AS "fee_source"
   FROM "mfn_with_rule" "fe";


ALTER VIEW "public"."vw_net_marketplace_estimated" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."vw_gross_profit_consolidated" WITH ("security_invoker"='on') AS
 WITH "actual_orders" AS (
         SELECT "foi"."amazon_order_id",
            "d"."seller_sku",
            "d"."product_name",
            "min"("fe"."posted_date") FILTER (WHERE ("fe"."event_type" = ANY (ARRAY['ItemCharge'::"text", 'ItemFee'::"text"]))) AS "posted_date",
            "fo"."purchase_date" AS "order_purchase_date",
            "fo"."order_status",
            COALESCE("fo"."fulfillment_channel", "foi"."fulfillment_channel") AS "order_fulfillment_channel",
            "fo"."sales_channel",
            "fo"."account_id",
            "foi"."order_item_id",
            "foi"."quantity_ordered",
            "foi"."item_price_amount",
            "foi"."item_revenue",
            COALESCE("foi"."promotion_discount_amount", (0)::numeric) AS "promotion_discount",
            COALESCE("foi"."cost_product", "d"."cost_product", (0)::numeric) AS "cost_product",
            "foi"."cost_status",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemCharge'::"text") AND ("fe"."charge_or_fee_type" = 'Principal'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "principal",
            (0)::numeric AS "shipping_charge",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemCharge'::"text") AND ("fe"."charge_or_fee_type" = 'Tax'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "tax",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemFee'::"text") AND ("fe"."charge_or_fee_type" = 'FBAPerUnitFulfillmentFee'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "fba_fee",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemFee'::"text") AND ("fe"."charge_or_fee_type" = 'Commission'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "commission",
            "sum"(
                CASE
                    WHEN ("fe"."event_type" = 'ItemFee'::"text") THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "total_item_fees",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ServiceFee'::"text") AND ("fe"."charge_or_fee_type" = 'MFNPostageFee'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "mfn_postage_fee_actual",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ServiceFee'::"text") AND ("fe"."charge_or_fee_type" = 'MFNShippingChargeback'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "mfn_shipping_chargeback",
            'actual'::"text" AS "fee_source"
           FROM ((("public"."fact_order_item" "foi"
             JOIN "public"."fact_order" "fo" ON ((("foi"."amazon_order_id")::"text" = ("fo"."amazon_order_id")::"text")))
             LEFT JOIN "public"."dim_seller_sku" "d" ON (("foi"."seller_sku_id" = "d"."id")))
             LEFT JOIN "public"."financial_events" "fe" ON ((("fe"."amazon_order_id" = ("foi"."amazon_order_id")::"text") AND ("fe"."event_type" = ANY (ARRAY['ItemCharge'::"text", 'ItemFee'::"text", 'ServiceFee'::"text"])))))
          GROUP BY "foi"."amazon_order_id", "d"."seller_sku", "d"."product_name", "fo"."purchase_date", "fo"."order_status", COALESCE("fo"."fulfillment_channel", "foi"."fulfillment_channel"), "fo"."sales_channel", "fo"."account_id", "foi"."order_item_id", "foi"."quantity_ordered", "foi"."item_price_amount", "foi"."item_revenue", "foi"."promotion_discount_amount", COALESCE("foi"."cost_product", "d"."cost_product", (0)::numeric), "foi"."cost_status"
        )
 SELECT "ao"."amazon_order_id",
    "ao"."seller_sku",
    "ao"."product_name",
    "ao"."posted_date",
    "ao"."order_purchase_date",
    "ao"."order_status",
    "ao"."order_fulfillment_channel",
    "ao"."sales_channel",
    "ao"."account_id",
    "ao"."order_item_id",
    "ao"."quantity_ordered",
    "ao"."item_price_amount",
    "ao"."item_revenue",
    ("ao"."promotion_discount" * ("ao"."quantity_ordered")::numeric) AS "promotion_discount",
    "ao"."cost_product",
    "ao"."cost_status",
    "ao"."principal",
    "ao"."shipping_charge",
    "ao"."tax",
    "ao"."fba_fee",
    "ao"."commission",
    ("ao"."total_item_fees" + "ao"."mfn_postage_fee_actual") AS "total_fees",
        CASE
            WHEN ("ao"."mfn_postage_fee_actual" <> (0)::numeric) THEN "ao"."mfn_postage_fee_actual"
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 30.00)) THEN ('-4.50'::numeric * ("ao"."quantity_ordered")::numeric)
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 79.00)) THEN ('-6.75'::numeric * ("ao"."quantity_ordered")::numeric)
            ELSE (0)::numeric
        END AS "mfn_postage_fee",
    "ao"."mfn_shipping_chargeback",
    (0)::numeric AS "total_service_fees",
    (((("ao"."principal" + "ao"."commission") + "ao"."fba_fee") +
        CASE
            WHEN ("ao"."mfn_postage_fee_actual" <> (0)::numeric) THEN "ao"."mfn_postage_fee_actual"
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 30.00)) THEN ('-4.50'::numeric * ("ao"."quantity_ordered")::numeric)
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 79.00)) THEN ('-6.75'::numeric * ("ao"."quantity_ordered")::numeric)
            ELSE (0)::numeric
        END) - ("ao"."promotion_discount" * ("ao"."quantity_ordered")::numeric)) AS "net_revenue",
    ((((("ao"."principal" + "ao"."commission") + "ao"."fba_fee") +
        CASE
            WHEN ("ao"."mfn_postage_fee_actual" <> (0)::numeric) THEN "ao"."mfn_postage_fee_actual"
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 30.00)) THEN ('-4.50'::numeric * ("ao"."quantity_ordered")::numeric)
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 79.00)) THEN ('-6.75'::numeric * ("ao"."quantity_ordered")::numeric)
            ELSE (0)::numeric
        END) - ("ao"."promotion_discount" * ("ao"."quantity_ordered")::numeric)) - ("ao"."cost_product" * ("ao"."quantity_ordered")::numeric)) AS "gross_profit",
    "ao"."fee_source"
   FROM "actual_orders" "ao"
  WHERE (EXISTS ( SELECT 1
           FROM "public"."financial_events" "fe"
          WHERE (("fe"."amazon_order_id" = ("ao"."amazon_order_id")::"text") AND ("fe"."event_type" = ANY (ARRAY['ItemCharge'::"text", 'ItemFee'::"text"])))))
UNION ALL
 SELECT "vw_net_marketplace_estimated"."amazon_order_id",
    "vw_net_marketplace_estimated"."seller_sku",
    "vw_net_marketplace_estimated"."product_name",
    "vw_net_marketplace_estimated"."posted_date",
    "vw_net_marketplace_estimated"."order_purchase_date",
    "vw_net_marketplace_estimated"."order_status",
    "vw_net_marketplace_estimated"."order_fulfillment_channel",
    "vw_net_marketplace_estimated"."sales_channel",
    "vw_net_marketplace_estimated"."account_id",
    "vw_net_marketplace_estimated"."order_item_id",
    "vw_net_marketplace_estimated"."quantity_ordered",
    "vw_net_marketplace_estimated"."item_price_amount",
    "vw_net_marketplace_estimated"."item_revenue",
    "vw_net_marketplace_estimated"."promotion_discount",
    "vw_net_marketplace_estimated"."cost_product",
    "vw_net_marketplace_estimated"."cost_status",
    "vw_net_marketplace_estimated"."principal",
    "vw_net_marketplace_estimated"."shipping_charge",
    "vw_net_marketplace_estimated"."tax",
    "vw_net_marketplace_estimated"."fba_fee",
    "vw_net_marketplace_estimated"."commission",
    "vw_net_marketplace_estimated"."total_fees",
    "vw_net_marketplace_estimated"."mfn_postage_fee",
    "vw_net_marketplace_estimated"."mfn_shipping_chargeback",
    "vw_net_marketplace_estimated"."total_service_fees",
    "vw_net_marketplace_estimated"."net_revenue",
    "vw_net_marketplace_estimated"."gross_profit",
    "vw_net_marketplace_estimated"."fee_source"
   FROM "public"."vw_net_marketplace_estimated";


ALTER VIEW "public"."vw_gross_profit_consolidated" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."vw_net_marketplace_estimated_v2" WITH ("security_invoker"='on') AS
 WITH "missing_orders" AS (
         SELECT "foi"."amazon_order_id",
            "d"."seller_sku",
            "d"."product_name",
            "fo"."purchase_date",
            "fo"."order_status",
            COALESCE("fo"."fulfillment_channel", "foi"."fulfillment_channel") AS "fulfillment_channel",
            "fo"."sales_channel",
            "fo"."account_id",
            "fo"."marketplace_account_id",
            "ma"."marketplace_id",
            "foi"."order_item_id",
            "foi"."quantity_ordered",
            "foi"."item_price_amount",
            "foi"."item_revenue",
            "foi"."promotion_discount_amount",
            COALESCE("foi"."cost_product", "d"."cost_product", (0)::numeric) AS "cost_product",
            "foi"."cost_status"
           FROM ((("public"."fact_order_item" "foi"
             JOIN "public"."fact_order" "fo" ON (("fo"."id" = "foi"."order_id")))
             LEFT JOIN "public"."dim_seller_sku" "d" ON (("foi"."seller_sku_id" = "d"."id")))
             LEFT JOIN "public"."marketplace_accounts" "ma" ON (("ma"."id" = "fo"."marketplace_account_id")))
          WHERE (NOT (EXISTS ( SELECT 1
                   FROM "public"."financial_events" "fe"
                  WHERE (("fe"."amazon_order_id" = ("foi"."amazon_order_id")::"text") AND ("fe"."marketplace_account_id" = "fo"."marketplace_account_id") AND ("fe"."event_type" = ANY (ARRAY['ItemCharge'::"text", 'ItemFee'::"text"]))))))
        ), "service_fees" AS (
         SELECT "fe"."amazon_order_id",
            "fe"."marketplace_account_id",
            "fe"."seller_sku",
            "sum"(
                CASE
                    WHEN ("fe"."charge_or_fee_type" = 'MFNPostageFee'::"text") THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "mfn_postage_fee_actual",
            "sum"(
                CASE
                    WHEN ("fe"."charge_or_fee_type" = 'MFNShippingChargeback'::"text") THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "mfn_shipping_chargeback"
           FROM "public"."financial_events" "fe"
          WHERE ("fe"."event_type" = 'ServiceFee'::"text")
          GROUP BY "fe"."amazon_order_id", "fe"."marketplace_account_id", "fe"."seller_sku"
        ), "last_mfn_fee" AS (
         SELECT DISTINCT ON ("fe"."marketplace_account_id", "fe"."seller_sku") "fe"."marketplace_account_id",
            "fe"."seller_sku",
            "fe"."amount" AS "mfn_postage_fee_hist"
           FROM "public"."financial_events" "fe"
          WHERE (("fe"."charge_or_fee_type" = 'MFNPostageFee'::"text") AND ("fe"."amount" <> (0)::numeric))
          ORDER BY "fe"."marketplace_account_id", "fe"."seller_sku", "fe"."posted_date" DESC
        ), "sp_api_fees" AS (
         SELECT DISTINCT ON ("mo"."order_item_id") "mo"."order_item_id",
            "mfe"."referral_fee",
            "mfe"."fba_fulfillment_fee",
            "mfe"."variable_closing_fee",
            "mfe"."mfn_postage_fee",
            "mfe"."total_fees",
            "mfe"."estimated_at"
           FROM ("missing_orders" "mo"
             LEFT JOIN LATERAL ( SELECT "mfe_1"."id",
                    "mfe_1"."seller_sku",
                    "mfe_1"."marketplace_id",
                    "mfe_1"."listing_price",
                    "mfe_1"."is_fba",
                    "mfe_1"."referral_fee",
                    "mfe_1"."fba_fulfillment_fee",
                    "mfe_1"."variable_closing_fee",
                    "mfe_1"."mfn_postage_fee",
                    "mfe_1"."total_fees",
                    "mfe_1"."estimated_at",
                    "mfe_1"."status",
                    "mfe_1"."raw_response"
                   FROM "public"."marketplace_fee_estimates" "mfe_1"
                  WHERE (("mfe_1"."seller_sku" = ("mo"."seller_sku")::"text") AND ("mfe_1"."marketplace_id" = ("mo"."marketplace_id")::"text") AND ("mfe_1"."listing_price" = "mo"."item_price_amount") AND ("mfe_1"."is_fba" = (("mo"."fulfillment_channel")::"text" = ANY (ARRAY['AFN'::"text", 'AMAZON'::"text"]))))
                  ORDER BY "mfe_1"."estimated_at" DESC
                 LIMIT 1) "mfe" ON (true))
        ), "hist_item" AS (
         SELECT "fe"."amazon_order_id",
            "fe"."marketplace_account_id",
            "fe"."seller_sku",
            "fe"."posted_date",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemCharge'::"text") AND ("fe"."charge_or_fee_type" = 'Principal'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "principal",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemFee'::"text") AND ("fe"."charge_or_fee_type" = 'FBAPerUnitFulfillmentFee'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "fba_fee",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemFee'::"text") AND ("fe"."charge_or_fee_type" = 'Commission'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "commission",
            "sum"(
                CASE
                    WHEN ("fe"."event_type" = 'ItemFee'::"text") THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "total_fees",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemCharge'::"text") AND ("fe"."charge_or_fee_type" = 'Tax'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "tax"
           FROM "public"."financial_events" "fe"
          WHERE ("fe"."event_type" = ANY (ARRAY['ItemCharge'::"text", 'ItemFee'::"text"]))
          GROUP BY "fe"."amazon_order_id", "fe"."marketplace_account_id", "fe"."seller_sku", "fe"."posted_date"
        ), "sku_stats" AS (
         SELECT "hi"."marketplace_account_id",
            "hi"."seller_sku",
            "avg"("hi"."tax") AS "avg_tax",
            "sum"("hi"."commission") AS "sum_commission",
            "sum"("hi"."principal") AS "sum_principal",
            "count"(*) AS "sample_count"
           FROM "hist_item" "hi"
          GROUP BY "hi"."marketplace_account_id", "hi"."seller_sku"
        ), "last_fba_sku" AS (
         SELECT DISTINCT ON ("hi"."marketplace_account_id", "hi"."seller_sku") "hi"."marketplace_account_id",
            "hi"."seller_sku",
            "hi"."fba_fee",
            "hi"."posted_date"
           FROM "hist_item" "hi"
          WHERE (("hi"."fba_fee" IS NOT NULL) AND ("hi"."fba_fee" <> (0)::numeric))
          ORDER BY "hi"."marketplace_account_id", "hi"."seller_sku", "hi"."posted_date" DESC
        ), "fallback_estimates" AS (
         SELECT "mo"."amazon_order_id",
            "mo"."seller_sku",
            "mo"."product_name",
            "mo"."purchase_date",
            "mo"."order_status",
            "mo"."fulfillment_channel",
            "mo"."sales_channel",
            "mo"."account_id",
            "mo"."marketplace_account_id",
            "mo"."order_item_id",
            "mo"."quantity_ordered",
            "mo"."item_price_amount",
            "mo"."item_revenue",
            "mo"."promotion_discount_amount",
            "mo"."cost_product",
            "mo"."cost_status",
                CASE
                    WHEN (("ss"."sample_count" >= 3) AND ("ss"."sum_principal" <> (0)::numeric)) THEN (("ss"."sum_commission" / "ss"."sum_principal") * "mo"."item_price_amount")
                    ELSE (0)::numeric
                END AS "est_commission_hist",
            COALESCE("lfs"."fba_fee", (0)::numeric) AS "est_fba_fee_hist",
            COALESCE("ss"."avg_tax", (0)::numeric) AS "est_tax_hist",
            "sp"."referral_fee",
            "sp"."fba_fulfillment_fee",
            "sp"."variable_closing_fee",
            "sp"."mfn_postage_fee",
            "sp"."total_fees",
            COALESCE("sf"."mfn_postage_fee_actual", (0)::numeric) AS "mfn_postage_fee_actual",
            COALESCE("sf"."mfn_shipping_chargeback", (0)::numeric) AS "mfn_shipping_chargeback",
            COALESCE("lmf"."mfn_postage_fee_hist", (0)::numeric) AS "mfn_postage_fee_hist"
           FROM ((((("missing_orders" "mo"
             LEFT JOIN "sku_stats" "ss" ON ((("mo"."marketplace_account_id" = "ss"."marketplace_account_id") AND (("mo"."seller_sku")::"text" = "ss"."seller_sku"))))
             LEFT JOIN "last_fba_sku" "lfs" ON ((("mo"."marketplace_account_id" = "lfs"."marketplace_account_id") AND (("mo"."seller_sku")::"text" = "lfs"."seller_sku"))))
             LEFT JOIN "sp_api_fees" "sp" ON ((("mo"."order_item_id")::"text" = ("sp"."order_item_id")::"text")))
             LEFT JOIN "service_fees" "sf" ON (((("mo"."amazon_order_id")::"text" = "sf"."amazon_order_id") AND ("mo"."marketplace_account_id" = "sf"."marketplace_account_id") AND (("mo"."seller_sku")::"text" = "sf"."seller_sku"))))
             LEFT JOIN "last_mfn_fee" "lmf" ON ((("mo"."marketplace_account_id" = "lmf"."marketplace_account_id") AND (("mo"."seller_sku")::"text" = "lmf"."seller_sku"))))
        ), "mfn_with_rule" AS (
         SELECT "fallback_estimates"."amazon_order_id",
            "fallback_estimates"."seller_sku",
            "fallback_estimates"."product_name",
            "fallback_estimates"."purchase_date",
            "fallback_estimates"."order_status",
            "fallback_estimates"."fulfillment_channel",
            "fallback_estimates"."sales_channel",
            "fallback_estimates"."account_id",
            "fallback_estimates"."order_item_id",
            "fallback_estimates"."quantity_ordered",
            "fallback_estimates"."item_price_amount",
            "fallback_estimates"."item_revenue",
            "fallback_estimates"."promotion_discount_amount",
            "fallback_estimates"."cost_product",
            "fallback_estimates"."cost_status",
            "fallback_estimates"."est_commission_hist",
            "fallback_estimates"."est_fba_fee_hist",
            "fallback_estimates"."est_tax_hist",
            "fallback_estimates"."referral_fee",
            "fallback_estimates"."fba_fulfillment_fee",
            "fallback_estimates"."variable_closing_fee",
            "fallback_estimates"."mfn_postage_fee",
            "fallback_estimates"."total_fees",
            "fallback_estimates"."mfn_postage_fee_actual",
            "fallback_estimates"."mfn_shipping_chargeback",
            "fallback_estimates"."mfn_postage_fee_hist",
            COALESCE(NULLIF("fallback_estimates"."mfn_postage_fee_actual", (0)::numeric), ("fallback_estimates"."mfn_postage_fee" * ("fallback_estimates"."quantity_ordered")::numeric), NULLIF(("fallback_estimates"."mfn_postage_fee_hist" * ("fallback_estimates"."quantity_ordered")::numeric), (0)::numeric),
                CASE
                    WHEN ((("fallback_estimates"."fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("fallback_estimates"."item_price_amount" / (NULLIF("fallback_estimates"."quantity_ordered", 0))::numeric) <= 30.00)) THEN ('-4.50'::numeric * ("fallback_estimates"."quantity_ordered")::numeric)
                    WHEN ((("fallback_estimates"."fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("fallback_estimates"."item_price_amount" / (NULLIF("fallback_estimates"."quantity_ordered", 0))::numeric) <= 79.00)) THEN ('-6.75'::numeric * ("fallback_estimates"."quantity_ordered")::numeric)
                    ELSE (0)::numeric
                END) AS "mfn_postage_fee_calculado"
           FROM "fallback_estimates"
        )
 SELECT "amazon_order_id",
    "seller_sku",
    "product_name",
    NULL::timestamp with time zone AS "posted_date",
    "purchase_date" AS "order_purchase_date",
    "order_status",
    "fulfillment_channel" AS "order_fulfillment_channel",
    "sales_channel",
    "account_id",
    "order_item_id",
    "quantity_ordered",
    "item_price_amount",
    "item_revenue",
    (COALESCE("promotion_discount_amount", (0)::numeric) * ("quantity_ordered")::numeric) AS "promotion_discount",
    "cost_product",
    "cost_status",
    ("item_price_amount" * ("quantity_ordered")::numeric) AS "principal",
    (0)::numeric AS "shipping_charge",
    ("est_tax_hist" * ("quantity_ordered")::numeric) AS "tax",
    (COALESCE("fba_fulfillment_fee", "est_fba_fee_hist", (0)::numeric) * ("quantity_ordered")::numeric) AS "fba_fee",
    (COALESCE("referral_fee", "est_commission_hist", (0)::numeric) * ("quantity_ordered")::numeric) AS "commission",
    (((COALESCE("referral_fee", "est_commission_hist", (0)::numeric) * ("quantity_ordered")::numeric) + (COALESCE("fba_fulfillment_fee", "est_fba_fee_hist", (0)::numeric) * ("quantity_ordered")::numeric)) + "mfn_postage_fee_calculado") AS "total_fees",
    "mfn_postage_fee_calculado" AS "mfn_postage_fee",
    "mfn_shipping_chargeback",
    (0)::numeric AS "total_service_fees",
    ((((("item_price_amount" * ("quantity_ordered")::numeric) + (COALESCE("referral_fee", "est_commission_hist", (0)::numeric) * ("quantity_ordered")::numeric)) + (COALESCE("fba_fulfillment_fee", "est_fba_fee_hist", (0)::numeric) * ("quantity_ordered")::numeric)) + "mfn_postage_fee_calculado") - (COALESCE("promotion_discount_amount", (0)::numeric) * ("quantity_ordered")::numeric)) AS "net_revenue",
    (((((("item_price_amount" * ("quantity_ordered")::numeric) + (COALESCE("referral_fee", "est_commission_hist", (0)::numeric) * ("quantity_ordered")::numeric)) + (COALESCE("fba_fulfillment_fee", "est_fba_fee_hist", (0)::numeric) * ("quantity_ordered")::numeric)) + "mfn_postage_fee_calculado") - (COALESCE("promotion_discount_amount", (0)::numeric) * ("quantity_ordered")::numeric)) - (COALESCE("cost_product", (0)::numeric) * ("quantity_ordered")::numeric)) AS "gross_profit",
        CASE
            WHEN ("referral_fee" IS NOT NULL) THEN 'sp_api'::"text"
            ELSE 'historical'::"text"
        END AS "fee_source"
   FROM "mfn_with_rule";


ALTER VIEW "public"."vw_net_marketplace_estimated_v2" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."vw_gross_profit_consolidated_v2" WITH ("security_invoker"='on') AS
 WITH "actual_orders" AS (
         SELECT "foi"."amazon_order_id",
            "d"."seller_sku",
            "d"."product_name",
            NULL::timestamp with time zone AS "posted_date",
            "fo"."purchase_date" AS "order_purchase_date",
            "fo"."order_status",
            COALESCE("fo"."fulfillment_channel", "foi"."fulfillment_channel") AS "order_fulfillment_channel",
            "fo"."sales_channel",
            "fo"."account_id",
            "foi"."order_item_id",
            "foi"."quantity_ordered",
            "foi"."item_price_amount",
            "foi"."item_revenue",
            COALESCE("foi"."promotion_discount_amount", (0)::numeric) AS "promotion_discount",
            COALESCE("foi"."cost_product", "d"."cost_product", (0)::numeric) AS "cost_product",
            "foi"."cost_status",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemCharge'::"text") AND ("fe"."charge_or_fee_type" = 'Principal'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "principal",
            (0)::numeric AS "shipping_charge",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemCharge'::"text") AND ("fe"."charge_or_fee_type" = 'Tax'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "tax",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemFee'::"text") AND ("fe"."charge_or_fee_type" = 'FBAPerUnitFulfillmentFee'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "fba_fee",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemFee'::"text") AND ("fe"."charge_or_fee_type" = 'Commission'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "commission",
            "sum"(
                CASE
                    WHEN ("fe"."event_type" = 'ItemFee'::"text") THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "total_item_fees",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ServiceFee'::"text") AND ("fe"."charge_or_fee_type" = 'MFNPostageFee'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "mfn_postage_fee_actual",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ServiceFee'::"text") AND ("fe"."charge_or_fee_type" = 'MFNShippingChargeback'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "mfn_shipping_chargeback",
            'actual'::"text" AS "fee_source"
           FROM ((("public"."fact_order_item" "foi"
             JOIN "public"."fact_order" "fo" ON (("fo"."id" = "foi"."order_id")))
             LEFT JOIN "public"."dim_seller_sku" "d" ON (("foi"."seller_sku_id" = "d"."id")))
             LEFT JOIN "public"."financial_events" "fe" ON ((("fe"."amazon_order_id" = ("foi"."amazon_order_id")::"text") AND ("fe"."marketplace_account_id" = "fo"."marketplace_account_id") AND ("fe"."event_type" = ANY (ARRAY['ItemCharge'::"text", 'ItemFee'::"text", 'ServiceFee'::"text"])))))
          GROUP BY "foi"."amazon_order_id", "d"."seller_sku", "d"."product_name", "fo"."purchase_date", "fo"."order_status", COALESCE("fo"."fulfillment_channel", "foi"."fulfillment_channel"), "fo"."sales_channel", "fo"."account_id", "foi"."order_item_id", "foi"."quantity_ordered", "foi"."item_price_amount", "foi"."item_revenue", "foi"."promotion_discount_amount", COALESCE("foi"."cost_product", "d"."cost_product", (0)::numeric), "foi"."cost_status"
        )
 SELECT "ao"."amazon_order_id",
    "ao"."seller_sku",
    "ao"."product_name",
    "ao"."posted_date",
    "ao"."order_purchase_date",
    "ao"."order_status",
    "ao"."order_fulfillment_channel",
    "ao"."sales_channel",
    "ao"."account_id",
    "ao"."order_item_id",
    "ao"."quantity_ordered",
    "ao"."item_price_amount",
    "ao"."item_revenue",
    ("ao"."promotion_discount" * ("ao"."quantity_ordered")::numeric) AS "promotion_discount",
    "ao"."cost_product",
    "ao"."cost_status",
    "ao"."principal",
    "ao"."shipping_charge",
    "ao"."tax",
    "ao"."fba_fee",
    "ao"."commission",
    ("ao"."total_item_fees" + "ao"."mfn_postage_fee_actual") AS "total_fees",
        CASE
            WHEN ("ao"."mfn_postage_fee_actual" <> (0)::numeric) THEN "ao"."mfn_postage_fee_actual"
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 30.00)) THEN ('-4.50'::numeric * ("ao"."quantity_ordered")::numeric)
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 79.00)) THEN ('-6.75'::numeric * ("ao"."quantity_ordered")::numeric)
            ELSE (0)::numeric
        END AS "mfn_postage_fee",
    "ao"."mfn_shipping_chargeback",
    (0)::numeric AS "total_service_fees",
    (((("ao"."principal" + "ao"."commission") + "ao"."fba_fee") +
        CASE
            WHEN ("ao"."mfn_postage_fee_actual" <> (0)::numeric) THEN "ao"."mfn_postage_fee_actual"
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 30.00)) THEN ('-4.50'::numeric * ("ao"."quantity_ordered")::numeric)
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 79.00)) THEN ('-6.75'::numeric * ("ao"."quantity_ordered")::numeric)
            ELSE (0)::numeric
        END) - ("ao"."promotion_discount" * ("ao"."quantity_ordered")::numeric)) AS "net_revenue",
    ((((("ao"."principal" + "ao"."commission") + "ao"."fba_fee") +
        CASE
            WHEN ("ao"."mfn_postage_fee_actual" <> (0)::numeric) THEN "ao"."mfn_postage_fee_actual"
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 30.00)) THEN ('-4.50'::numeric * ("ao"."quantity_ordered")::numeric)
            WHEN ((("ao"."order_fulfillment_channel")::"text" = ANY (ARRAY['DBA'::"text", 'MFN'::"text"])) AND (("ao"."item_price_amount" / (NULLIF("ao"."quantity_ordered", 0))::numeric) <= 79.00)) THEN ('-6.75'::numeric * ("ao"."quantity_ordered")::numeric)
            ELSE (0)::numeric
        END) - ("ao"."promotion_discount" * ("ao"."quantity_ordered")::numeric)) - ("ao"."cost_product" * ("ao"."quantity_ordered")::numeric)) AS "gross_profit",
    "ao"."fee_source"
   FROM "actual_orders" "ao"
  WHERE (EXISTS ( SELECT 1
           FROM "public"."financial_events" "fe"
          WHERE (("fe"."amazon_order_id" = ("ao"."amazon_order_id")::"text") AND ("fe"."marketplace_account_id" = ( SELECT "fo"."marketplace_account_id"
                   FROM "public"."fact_order" "fo"
                  WHERE (("fo"."amazon_order_id")::"text" = ("ao"."amazon_order_id")::"text")
                 LIMIT 1)) AND ("fe"."event_type" = ANY (ARRAY['ItemCharge'::"text", 'ItemFee'::"text"])))))
UNION ALL
 SELECT "v"."amazon_order_id",
    "v"."seller_sku",
    "v"."product_name",
    "v"."posted_date",
    "v"."order_purchase_date",
    "v"."order_status",
    "v"."order_fulfillment_channel",
    "v"."sales_channel",
    "v"."account_id",
    "v"."order_item_id",
    "v"."quantity_ordered",
    "v"."item_price_amount",
    "v"."item_revenue",
    "v"."promotion_discount",
    "v"."cost_product",
    "v"."cost_status",
    "v"."principal",
    "v"."shipping_charge",
    "v"."tax",
    "v"."fba_fee",
    "v"."commission",
    "v"."total_fees",
    "v"."mfn_postage_fee",
    "v"."mfn_shipping_chargeback",
    "v"."total_service_fees",
    "v"."net_revenue",
    "v"."gross_profit",
    "v"."fee_source"
   FROM "public"."vw_net_marketplace_estimated_v2" "v";


ALTER VIEW "public"."vw_gross_profit_consolidated_v2" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."vw_net_marketplace" WITH ("security_invoker"='true') AS
 WITH "item_events" AS (
         SELECT "fe"."amazon_order_id",
            "fe"."seller_sku",
            "fe"."posted_date",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemCharge'::"text") AND ("fe"."charge_or_fee_type" = 'Principal'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "principal",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemCharge'::"text") AND ("fe"."charge_or_fee_type" = 'ShippingCharge'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "shipping_charge",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemCharge'::"text") AND ("fe"."charge_or_fee_type" = 'Tax'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "tax",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemFee'::"text") AND ("fe"."charge_or_fee_type" = 'FBAPerUnitFulfillmentFee'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "fba_fee",
            "sum"(
                CASE
                    WHEN (("fe"."event_type" = 'ItemFee'::"text") AND ("fe"."charge_or_fee_type" = 'Commission'::"text")) THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "commission",
            "sum"(
                CASE
                    WHEN ("fe"."event_type" = 'ItemFee'::"text") THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "total_fees"
           FROM "public"."financial_events" "fe"
          WHERE ("fe"."event_type" = ANY (ARRAY['ItemCharge'::"text", 'ItemFee'::"text"]))
          GROUP BY "fe"."amazon_order_id", "fe"."seller_sku", "fe"."posted_date"
        ), "service_fees" AS (
         SELECT "fe"."amazon_order_id",
            "sum"(
                CASE
                    WHEN ("fe"."charge_or_fee_type" = 'MFNPostageFee'::"text") THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "mfn_postage_fee",
            "sum"(
                CASE
                    WHEN ("fe"."charge_or_fee_type" = 'MFNShippingChargeback'::"text") THEN "fe"."amount"
                    ELSE (0)::numeric
                END) AS "mfn_shipping_chargeback",
            "sum"("fe"."amount") AS "total_service_fees"
           FROM "public"."financial_events" "fe"
          WHERE ("fe"."event_type" = 'ServiceFee'::"text")
          GROUP BY "fe"."amazon_order_id"
        )
 SELECT "ie"."amazon_order_id",
    "ie"."seller_sku",
    "d"."product_name",
    "ie"."posted_date",
    "fo"."purchase_date" AS "order_purchase_date",
    "fo"."order_status",
    "fo"."fulfillment_channel" AS "order_fulfillment_channel",
    "fo"."sales_channel",
    "fo"."account_id",
    "foi"."order_item_id",
    "foi"."quantity_ordered",
    "foi"."item_price_amount",
    "foi"."item_revenue",
    COALESCE("foi"."promotion_discount_amount", (0)::numeric) AS "promotion_discount",
    COALESCE("d"."cost_product", (0)::numeric) AS "cost_product",
    "foi"."cost_status",
    "ie"."principal",
    "ie"."shipping_charge",
    "ie"."tax",
    "ie"."fba_fee",
    "ie"."commission",
    "ie"."total_fees",
    COALESCE("sf"."mfn_postage_fee", (0)::numeric) AS "mfn_postage_fee",
    COALESCE("sf"."mfn_shipping_chargeback", (0)::numeric) AS "mfn_shipping_chargeback",
    COALESCE("sf"."total_service_fees", (0)::numeric) AS "total_service_fees",
    (((("ie"."principal" + "ie"."shipping_charge") + "ie"."total_fees") + COALESCE("sf"."total_service_fees", (0)::numeric)) - COALESCE("foi"."promotion_discount_amount", (0)::numeric)) AS "net_revenue",
    ((((("ie"."principal" + "ie"."shipping_charge") + "ie"."total_fees") + COALESCE("sf"."total_service_fees", (0)::numeric)) - COALESCE("foi"."promotion_discount_amount", (0)::numeric)) - (COALESCE("d"."cost_product", (0)::numeric) * (COALESCE("foi"."quantity_ordered", 0))::numeric)) AS "gross_profit"
   FROM (((("item_events" "ie"
     LEFT JOIN "public"."fact_order" "fo" ON (("ie"."amazon_order_id" = ("fo"."amazon_order_id")::"text")))
     LEFT JOIN "public"."fact_order_item" "foi" ON ((("ie"."amazon_order_id" = ("foi"."amazon_order_id")::"text") AND ("ie"."seller_sku" = (( SELECT "d2"."seller_sku"
           FROM "public"."dim_seller_sku" "d2"
          WHERE ("d2"."id" = "foi"."seller_sku_id")))::"text"))))
     LEFT JOIN "public"."dim_seller_sku" "d" ON (("foi"."seller_sku_id" = "d"."id")))
     LEFT JOIN "service_fees" "sf" ON (("ie"."amazon_order_id" = "sf"."amazon_order_id")));


ALTER VIEW "public"."vw_net_marketplace" OWNER TO "postgres";


ALTER TABLE ONLY "public"."api_sources" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."api_sources_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."integration_sources" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."integration_sources_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."orders_amazon" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."orders_amazon_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."sync_execution" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."sync_execution_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."account_sku_costs"
    ADD CONSTRAINT "account_sku_costs_pkey" PRIMARY KEY ("account_id", "seller_sku");



ALTER TABLE ONLY "public"."amazon_orders_raw"
    ADD CONSTRAINT "amazon_orders_raw_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."api_sources"
    ADD CONSTRAINT "api_sources_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."api_sources"
    ADD CONSTRAINT "api_sources_service_version_key" UNIQUE ("service", "version");



ALTER TABLE ONLY "public"."app_config"
    ADD CONSTRAINT "app_config_pkey" PRIMARY KEY ("key");



ALTER TABLE ONLY "public"."bling_accounts"
    ADD CONSTRAINT "bling_accounts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."bling_accounts"
    ADD CONSTRAINT "bling_accounts_seller_id_key" UNIQUE ("seller_id");



ALTER TABLE ONLY "public"."bridge_seller_sku_identifier"
    ADD CONSTRAINT "bridge_seller_sku_identifier_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."dim_date"
    ADD CONSTRAINT "dim_date_pkey" PRIMARY KEY ("date_key");



ALTER TABLE ONLY "public"."dim_financial_category"
    ADD CONSTRAINT "dim_financial_category_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."dim_seller_sku"
    ADD CONSTRAINT "dim_seller_sku_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."dim_seller_sku"
    ADD CONSTRAINT "dim_seller_sku_sku_account_key" UNIQUE ("seller_sku", "marketplace_account_id");



ALTER TABLE ONLY "public"."fact_financial_transaction"
    ADD CONSTRAINT "fact_financial_transaction_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."fact_order_item"
    ADD CONSTRAINT "fact_order_item_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."fact_order"
    ADD CONSTRAINT "fact_order_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."financial_checkpoint"
    ADD CONSTRAINT "financial_checkpoint_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."financial_events"
    ADD CONSTRAINT "financial_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."integration_sources"
    ADD CONSTRAINT "integration_sources_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."integration_sources"
    ADD CONSTRAINT "integration_sources_provider_service_version_key" UNIQUE ("provider", "service", "version");



ALTER TABLE ONLY "public"."login_attempts"
    ADD CONSTRAINT "login_attempts_pkey" PRIMARY KEY ("key");



ALTER TABLE ONLY "public"."marketplace_accounts"
    ADD CONSTRAINT "marketplace_accounts_amazon_seller_id_key" UNIQUE ("amazon_seller_id");



ALTER TABLE ONLY "public"."marketplace_accounts"
    ADD CONSTRAINT "marketplace_accounts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."marketplace_fee_estimates"
    ADD CONSTRAINT "marketplace_fee_estimates_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."marketplace_fee_estimates"
    ADD CONSTRAINT "marketplace_fee_estimates_seller_sku_marketplace_id_listing_key" UNIQUE ("seller_sku", "marketplace_id", "listing_price", "is_fba");



ALTER TABLE ONLY "public"."ml_accounts"
    ADD CONSTRAINT "ml_accounts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ml_accounts"
    ADD CONSTRAINT "ml_accounts_user_id_ml_user_id_key" UNIQUE ("user_id", "ml_user_id");



ALTER TABLE ONLY "public"."ml_oauth_states"
    ADD CONSTRAINT "ml_oauth_states_pkey" PRIMARY KEY ("state");



ALTER TABLE ONLY "public"."orders_amazon"
    ADD CONSTRAINT "orders_amazon_order_item_id_key" UNIQUE ("order_item_id");



ALTER TABLE ONLY "public"."orders_amazon"
    ADD CONSTRAINT "orders_amazon_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."orders_checkpoint"
    ADD CONSTRAINT "orders_checkpoint_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."sellers"
    ADD CONSTRAINT "sellers_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."stg_financial_transactions_amazon"
    ADD CONSTRAINT "stg_financial_transactions_amazon_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."stg_order_items_amazon"
    ADD CONSTRAINT "stg_order_items_amazon_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."stg_order_items_mercadolivre"
    ADD CONSTRAINT "stg_order_items_mercadolivre_pkey" PRIMARY KEY ("ml_account_id", "order_id", "item_id", "variation_id");



ALTER TABLE ONLY "public"."stg_orders_amazon"
    ADD CONSTRAINT "stg_orders_amazon_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."stg_orders_mercadolivre"
    ADD CONSTRAINT "stg_orders_mercadolivre_pkey" PRIMARY KEY ("ml_account_id", "order_id");



ALTER TABLE ONLY "public"."sync_checkpoint_orders"
    ADD CONSTRAINT "sync_checkpoint_orders_pkey" PRIMARY KEY ("account_id", "marketplace_provider");



ALTER TABLE ONLY "public"."sync_checkpoint"
    ADD CONSTRAINT "sync_checkpoint_pkey" PRIMARY KEY ("source");



ALTER TABLE ONLY "public"."sync_execution"
    ADD CONSTRAINT "sync_execution_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."dim_seller_sku"
    ADD CONSTRAINT "uq_dim_seller_sku" UNIQUE ("marketplace_account_id", "seller_sku", "asin");



ALTER TABLE ONLY "public"."fact_financial_transaction"
    ADD CONSTRAINT "uq_fact_financial_transaction_event" UNIQUE ("financial_event_id");



ALTER TABLE ONLY "public"."fact_order"
    ADD CONSTRAINT "uq_fact_order_amazon_order" UNIQUE ("amazon_order_id");



ALTER TABLE ONLY "public"."fact_order_item"
    ADD CONSTRAINT "uq_fact_order_item" UNIQUE ("amazon_order_id", "order_item_id");



ALTER TABLE ONLY "public"."fact_order_item"
    ADD CONSTRAINT "uq_fact_order_item_amazon" UNIQUE ("amazon_order_id", "order_item_id");



ALTER TABLE ONLY "public"."fact_financial_transaction"
    ADD CONSTRAINT "uq_financial_event" UNIQUE ("financial_event_id");



ALTER TABLE ONLY "public"."financial_events"
    ADD CONSTRAINT "uq_financial_events" UNIQUE ("amazon_order_id", "posted_date", "event_type", "charge_or_fee_type");



ALTER TABLE ONLY "public"."dim_financial_category"
    ADD CONSTRAINT "uq_financial_mapping" UNIQUE ("api_event_type", "api_charge_type");



ALTER TABLE ONLY "public"."bridge_seller_sku_identifier"
    ADD CONSTRAINT "uq_identifier" UNIQUE ("marketplace", "identifier_type", "identifier_value");



ALTER TABLE ONLY "public"."stg_orders_amazon"
    ADD CONSTRAINT "uq_stg_orders_amazon_order_id" UNIQUE ("amazon_order_id");



CREATE INDEX "idx_dim_seller_sku_asin" ON "public"."dim_seller_sku" USING "btree" ("asin");



CREATE INDEX "idx_dim_seller_sku_category" ON "public"."dim_seller_sku" USING "btree" ("category");



CREATE INDEX "idx_dim_seller_sku_status" ON "public"."dim_seller_sku" USING "btree" ("status");



CREATE INDEX "idx_fact_financial_transaction_category" ON "public"."fact_financial_transaction" USING "btree" ("financial_category_id");



CREATE INDEX "idx_fact_financial_transaction_date" ON "public"."fact_financial_transaction" USING "btree" ("transaction_date");



CREATE INDEX "idx_fact_financial_transaction_order" ON "public"."fact_financial_transaction" USING "btree" ("amazon_order_id");



CREATE INDEX "idx_fact_financial_transaction_sku" ON "public"."fact_financial_transaction" USING "btree" ("seller_sku_id");



CREATE INDEX "idx_fact_financial_transaction_type" ON "public"."fact_financial_transaction" USING "btree" ("event_type", "charge_or_fee_type");



CREATE INDEX "idx_fact_order_account" ON "public"."fact_order" USING "btree" ("account_id");



CREATE INDEX "idx_fact_order_item_account" ON "public"."fact_order_item" USING "btree" ("account_id");



CREATE INDEX "idx_fact_order_item_amazon_order" ON "public"."fact_order_item" USING "btree" ("amazon_order_id");



CREATE INDEX "idx_fact_order_item_order" ON "public"."fact_order_item" USING "btree" ("order_id");



CREATE INDEX "idx_fact_order_item_seller_sku_id" ON "public"."fact_order_item" USING "btree" ("seller_sku_id");



CREATE INDEX "idx_fact_order_marketplace" ON "public"."fact_order" USING "btree" ("marketplace_id");



CREATE INDEX "idx_fact_order_order_date" ON "public"."fact_order" USING "btree" ("order_date");



CREATE INDEX "idx_fact_order_purchase_date" ON "public"."fact_order" USING "btree" ("purchase_date");



CREATE INDEX "idx_fact_order_status" ON "public"."fact_order" USING "btree" ("order_status");



CREATE INDEX "idx_fee_est_lookup" ON "public"."marketplace_fee_estimates" USING "btree" ("seller_sku", "listing_price", "is_fba");



CREATE INDEX "idx_fee_est_sku" ON "public"."marketplace_fee_estimates" USING "btree" ("seller_sku");



CREATE INDEX "idx_financial_events_account" ON "public"."financial_events" USING "btree" ("account_id");



CREATE INDEX "idx_financial_events_date" ON "public"."financial_events" USING "btree" ("posted_date");



CREATE INDEX "idx_financial_events_order" ON "public"."financial_events" USING "btree" ("amazon_order_id");



CREATE INDEX "idx_financial_events_type" ON "public"."financial_events" USING "btree" ("event_type", "charge_or_fee_type");



CREATE UNIQUE INDEX "idx_financial_events_unique" ON "public"."financial_events" USING "btree" ("amazon_order_id", "posted_date", "event_type", "charge_or_fee_type");



CREATE UNIQUE INDEX "idx_orders_amazon_item_id" ON "public"."orders_amazon" USING "btree" ("order_item_id");



CREATE INDEX "idx_orders_canal" ON "public"."orders_amazon" USING "btree" ("canal_logistica");



CREATE INDEX "idx_orders_created_time" ON "public"."orders_amazon" USING "btree" ("created_time");



CREATE INDEX "idx_orders_order_item_id" ON "public"."orders_amazon" USING "btree" ("order_item_id");



CREATE INDEX "idx_stg_ml_items_user" ON "public"."stg_order_items_mercadolivre" USING "btree" ("user_id", "order_id");



CREATE INDEX "idx_stg_ml_orders_user" ON "public"."stg_orders_mercadolivre" USING "btree" ("user_id", "date_created" DESC);



CREATE INDEX "idx_stg_order_items_asin" ON "public"."stg_order_items_amazon" USING "btree" ("asin");



CREATE INDEX "idx_stg_order_items_order_id" ON "public"."stg_order_items_amazon" USING "btree" ("amazon_order_id");



CREATE INDEX "idx_stg_order_items_sku" ON "public"."stg_order_items_amazon" USING "btree" ("seller_sku");



CREATE INDEX "idx_stg_orders_amazon_order_id" ON "public"."stg_orders_amazon" USING "btree" ("amazon_order_id");



CREATE INDEX "idx_stg_orders_amazon_processed" ON "public"."stg_orders_amazon" USING "btree" ("processed");



CREATE INDEX "idx_stg_orders_amazon_purchase_date" ON "public"."stg_orders_amazon" USING "btree" ("purchase_date");



CREATE INDEX "ix_bridge_identifier_lookup" ON "public"."bridge_seller_sku_identifier" USING "btree" ("identifier_value");



CREATE INDEX "ix_bridge_seller_sku_id" ON "public"."bridge_seller_sku_identifier" USING "btree" ("seller_sku_id");



CREATE INDEX "ix_bridge_sku_identifier_lookup" ON "public"."bridge_seller_sku_identifier" USING "btree" ("identifier_value");



CREATE INDEX "ix_bridge_sku_identifier_sku" ON "public"."bridge_seller_sku_identifier" USING "btree" ("seller_sku_id");



CREATE INDEX "ix_fact_financial_transaction_category" ON "public"."fact_financial_transaction" USING "btree" ("financial_category_id");



CREATE INDEX "ix_fact_financial_transaction_category_id" ON "public"."fact_financial_transaction" USING "btree" ("financial_category_id");



CREATE INDEX "ix_fact_financial_transaction_sku" ON "public"."fact_financial_transaction" USING "btree" ("seller_sku_id");



CREATE INDEX "ix_fact_financial_transaction_sku_id" ON "public"."fact_financial_transaction" USING "btree" ("seller_sku_id");



CREATE INDEX "ix_fact_order_item_order_id" ON "public"."fact_order_item" USING "btree" ("order_id");



CREATE INDEX "ix_fact_order_item_order_item" ON "public"."fact_order_item" USING "btree" ("order_item_id");



CREATE INDEX "ix_fact_order_item_seller_sku_id" ON "public"."fact_order_item" USING "btree" ("seller_sku_id");



CREATE INDEX "ix_fact_order_order_date" ON "public"."fact_order" USING "btree" ("order_date");



CREATE INDEX "ix_raw_last_update" ON "public"."amazon_orders_raw" USING "btree" ("last_update_date");



CREATE INDEX "ix_raw_processed" ON "public"."amazon_orders_raw" USING "btree" ("processed");



CREATE INDEX "ix_raw_received" ON "public"."amazon_orders_raw" USING "btree" ("received_at");



CREATE INDEX "ix_stg_financial_transaction_event_date" ON "public"."stg_financial_transactions_amazon" USING "btree" ("event_date");



CREATE INDEX "ix_stg_financial_transaction_order" ON "public"."stg_financial_transactions_amazon" USING "btree" ("amazon_order_id");



CREATE INDEX "ix_stg_financial_transaction_processed" ON "public"."stg_financial_transactions_amazon" USING "btree" ("processed") WHERE ("processed" = false);



CREATE INDEX "ix_stg_financial_transaction_sku" ON "public"."stg_financial_transactions_amazon" USING "btree" ("seller_sku");



CREATE INDEX "ix_stg_order_items_order" ON "public"."stg_order_items_amazon" USING "btree" ("amazon_order_id");



CREATE INDEX "ix_stg_order_items_pending" ON "public"."stg_order_items_amazon" USING "btree" ("processed") WHERE ("processed" = false);



CREATE INDEX "ix_stg_orders_amazon_pending" ON "public"."stg_orders_amazon" USING "btree" ("processed") WHERE ("processed" = false);



CREATE UNIQUE INDEX "marketplace_accounts_provider_merchant_key" ON "public"."marketplace_accounts" USING "btree" ("marketplace_provider", "merchant_id") WHERE ("merchant_id" IS NOT NULL);



CREATE INDEX "marketplace_accounts_seller_id_idx" ON "public"."marketplace_accounts" USING "btree" ("seller_id");



CREATE INDEX "stg_orders_ml_seller_idx" ON "public"."stg_orders_mercadolivre" USING "btree" ("seller_id", "date_created" DESC);



CREATE UNIQUE INDEX "stg_orders_ml_uq" ON "public"."stg_orders_mercadolivre" USING "btree" ("ml_user_id", "order_id");



CREATE UNIQUE INDEX "uniq_financial_events_dedup" ON "public"."financial_events" USING "btree" ("amazon_order_id", COALESCE("seller_sku", ''::"text"), "event_type", "charge_or_fee_type", "amount");



CREATE UNIQUE INDEX "uq_dim_seller_sku_account" ON "public"."dim_seller_sku" USING "btree" ("seller_sku", "marketplace_account_id");



CREATE UNIQUE INDEX "uq_fact_order_item_order_item" ON "public"."fact_order_item" USING "btree" ("amazon_order_id", "order_item_id");



CREATE UNIQUE INDEX "uq_stg_order_items_order_item" ON "public"."stg_order_items_amazon" USING "btree" ("amazon_order_id", "order_item_id") WHERE ("order_item_id" IS NOT NULL);



CREATE UNIQUE INDEX "ux_bridge_identifier" ON "public"."bridge_seller_sku_identifier" USING "btree" ("marketplace", "identifier_type", "identifier_value");



CREATE UNIQUE INDEX "ux_raw_account_order" ON "public"."amazon_orders_raw" USING "btree" ("account_id", "amazon_order_id");



CREATE UNIQUE INDEX "ux_stg_financial_transaction_event" ON "public"."stg_financial_transactions_amazon" USING "btree" ("financial_event_id");



CREATE OR REPLACE TRIGGER "trg_estimate_fees" AFTER INSERT ON "public"."fact_order_item" FOR EACH ROW EXECUTE FUNCTION "public"."trigger_estimate_fees"();

ALTER TABLE "public"."fact_order_item" DISABLE TRIGGER "trg_estimate_fees";



CREATE OR REPLACE TRIGGER "trg_protect_cost_product" BEFORE INSERT OR UPDATE ON "public"."fact_order_item" FOR EACH ROW EXECUTE FUNCTION "public"."fn_protect_cost_product"();



ALTER TABLE ONLY "public"."amazon_orders_raw"
    ADD CONSTRAINT "amazon_orders_raw_api_source_id_fkey" FOREIGN KEY ("api_source_id") REFERENCES "public"."api_sources"("id");



ALTER TABLE ONLY "public"."bling_accounts"
    ADD CONSTRAINT "bling_accounts_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "public"."sellers"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."fact_order"
    ADD CONSTRAINT "fact_order_account_id_fkey" FOREIGN KEY ("account_id") REFERENCES "public"."marketplace_accounts"("id");



ALTER TABLE ONLY "public"."fact_order_item"
    ADD CONSTRAINT "fact_order_item_account_id_fkey" FOREIGN KEY ("account_id") REFERENCES "public"."marketplace_accounts"("id");



ALTER TABLE ONLY "public"."financial_events"
    ADD CONSTRAINT "financial_events_account_id_fkey" FOREIGN KEY ("account_id") REFERENCES "public"."marketplace_accounts"("id");



ALTER TABLE ONLY "public"."bridge_seller_sku_identifier"
    ADD CONSTRAINT "fk_bridge_seller_sku_identifier_sku" FOREIGN KEY ("seller_sku_id") REFERENCES "public"."dim_seller_sku"("id");



ALTER TABLE ONLY "public"."bridge_seller_sku_identifier"
    ADD CONSTRAINT "fk_bridge_sku" FOREIGN KEY ("seller_sku_id") REFERENCES "public"."dim_seller_sku"("id");



ALTER TABLE ONLY "public"."fact_financial_transaction"
    ADD CONSTRAINT "fk_fact_financial_transaction_category" FOREIGN KEY ("financial_category_id") REFERENCES "public"."dim_financial_category"("id");



ALTER TABLE ONLY "public"."fact_financial_transaction"
    ADD CONSTRAINT "fk_fact_financial_transaction_date" FOREIGN KEY ("transaction_date_key") REFERENCES "public"."dim_date"("date_key");



ALTER TABLE ONLY "public"."fact_financial_transaction"
    ADD CONSTRAINT "fk_fact_financial_transaction_sku" FOREIGN KEY ("seller_sku_id") REFERENCES "public"."dim_seller_sku"("id");



ALTER TABLE ONLY "public"."fact_order"
    ADD CONSTRAINT "fk_fact_order_date" FOREIGN KEY ("order_date") REFERENCES "public"."dim_date"("date_key");



ALTER TABLE ONLY "public"."fact_order_item"
    ADD CONSTRAINT "fk_fact_order_item_order" FOREIGN KEY ("order_id") REFERENCES "public"."fact_order"("id");



ALTER TABLE ONLY "public"."fact_order_item"
    ADD CONSTRAINT "fk_fact_order_item_seller_sku" FOREIGN KEY ("seller_sku_id") REFERENCES "public"."dim_seller_sku"("id");



ALTER TABLE ONLY "public"."marketplace_accounts"
    ADD CONSTRAINT "marketplace_accounts_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "public"."sellers"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."marketplace_accounts"
    ADD CONSTRAINT "marketplace_accounts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."ml_accounts"
    ADD CONSTRAINT "ml_accounts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ml_oauth_states"
    ADD CONSTRAINT "ml_oauth_states_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."stg_order_items_mercadolivre"
    ADD CONSTRAINT "stg_order_items_mercadolivre_ml_account_id_fkey" FOREIGN KEY ("ml_account_id") REFERENCES "public"."ml_accounts"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."stg_orders_mercadolivre"
    ADD CONSTRAINT "stg_orders_mercadolivre_ml_account_id_fkey" FOREIGN KEY ("ml_account_id") REFERENCES "public"."ml_accounts"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."sync_checkpoint_orders"
    ADD CONSTRAINT "sync_checkpoint_orders_account_id_fkey" FOREIGN KEY ("account_id") REFERENCES "public"."marketplace_accounts"("id");



CREATE POLICY "Allow public registration on sellers" ON "public"."sellers" FOR INSERT TO "anon", "authenticated" WITH CHECK (true);



CREATE POLICY "Allow read on sellers" ON "public"."sellers" FOR SELECT TO "anon", "authenticated" USING (true);



ALTER TABLE "public"."account_sku_costs" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "allow_anon_upsert" ON "public"."orders_amazon" TO "anon" USING (true) WITH CHECK (true);



ALTER TABLE "public"."amazon_orders_raw" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."api_sources" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."app_config" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."bling_accounts" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."bridge_seller_sku_identifier" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."dim_date" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."dim_financial_category" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."dim_seller_sku" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."fact_financial_transaction" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."fact_order" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."fact_order_item" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."financial_checkpoint" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."financial_events" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."integration_sources" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."login_attempts" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."marketplace_accounts" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."marketplace_fee_estimates" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ml_accounts" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "ml_accounts_select_own" ON "public"."ml_accounts" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



ALTER TABLE "public"."ml_oauth_states" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."orders_amazon" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."orders_checkpoint" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "select_contas_autenticados" ON "public"."marketplace_accounts" FOR SELECT TO "authenticated" USING (true);



ALTER TABLE "public"."sellers" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."stg_financial_transactions_amazon" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "stg_ml_items_select_own" ON "public"."stg_order_items_mercadolivre" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "stg_ml_orders_select_own" ON "public"."stg_orders_mercadolivre" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



ALTER TABLE "public"."stg_order_items_amazon" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."stg_order_items_mercadolivre" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."stg_orders_amazon" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."stg_orders_mercadolivre" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."sync_checkpoint" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."sync_checkpoint_orders" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."sync_execution" ENABLE ROW LEVEL SECURITY;




ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";








GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";

















































































































































































GRANT ALL ON FUNCTION "public"."fn_protect_cost_product"() TO "anon";
GRANT ALL ON FUNCTION "public"."fn_protect_cost_product"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_protect_cost_product"() TO "service_role";



GRANT ALL ON FUNCTION "public"."get_max_created_after"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_max_created_after"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_max_created_after"() TO "service_role";



GRANT ALL ON FUNCTION "public"."get_pending_fee_estimates"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_pending_fee_estimates"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_pending_fee_estimates"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."is_login_blocked"("p_key" "text", "p_max" integer, "p_window_seconds" integer) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."is_login_blocked"("p_key" "text", "p_max" integer, "p_window_seconds" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."load_fact_order"() TO "anon";
GRANT ALL ON FUNCTION "public"."load_fact_order"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."load_fact_order"() TO "service_role";



GRANT ALL ON FUNCTION "public"."load_fact_order_item"() TO "anon";
GRANT ALL ON FUNCTION "public"."load_fact_order_item"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."load_fact_order_item"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."register_login_failure"("p_key" "text", "p_window_seconds" integer) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."register_login_failure"("p_key" "text", "p_window_seconds" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."reprocess_costs"("p_sku" "text", "p_from" timestamp with time zone, "p_to" timestamp with time zone, "p_account_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."reprocess_costs"("p_sku" "text", "p_from" timestamp with time zone, "p_to" timestamp with time zone, "p_account_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."reprocess_costs"("p_sku" "text", "p_from" timestamp with time zone, "p_to" timestamp with time zone, "p_account_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."trigger_estimate_fees"() TO "anon";
GRANT ALL ON FUNCTION "public"."trigger_estimate_fees"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."trigger_estimate_fees"() TO "service_role";



GRANT ALL ON FUNCTION "public"."upsert_orders_batch"("p_orders" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "public"."upsert_orders_batch"("p_orders" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "public"."upsert_orders_batch"("p_orders" "jsonb") TO "service_role";
























GRANT ALL ON TABLE "public"."account_sku_costs" TO "anon";
GRANT ALL ON TABLE "public"."account_sku_costs" TO "authenticated";
GRANT ALL ON TABLE "public"."account_sku_costs" TO "service_role";



GRANT ALL ON TABLE "public"."amazon_orders_raw" TO "anon";
GRANT ALL ON TABLE "public"."amazon_orders_raw" TO "authenticated";
GRANT ALL ON TABLE "public"."amazon_orders_raw" TO "service_role";



GRANT ALL ON SEQUENCE "public"."amazon_orders_raw_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."amazon_orders_raw_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."amazon_orders_raw_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."api_sources" TO "anon";
GRANT ALL ON TABLE "public"."api_sources" TO "authenticated";
GRANT ALL ON TABLE "public"."api_sources" TO "service_role";



GRANT ALL ON SEQUENCE "public"."api_sources_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."api_sources_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."api_sources_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."app_config" TO "anon";
GRANT ALL ON TABLE "public"."app_config" TO "authenticated";
GRANT ALL ON TABLE "public"."app_config" TO "service_role";



GRANT ALL ON TABLE "public"."bling_accounts" TO "anon";
GRANT ALL ON TABLE "public"."bling_accounts" TO "authenticated";
GRANT ALL ON TABLE "public"."bling_accounts" TO "service_role";



GRANT ALL ON TABLE "public"."bridge_seller_sku_identifier" TO "anon";
GRANT ALL ON TABLE "public"."bridge_seller_sku_identifier" TO "authenticated";
GRANT ALL ON TABLE "public"."bridge_seller_sku_identifier" TO "service_role";



GRANT ALL ON SEQUENCE "public"."bridge_seller_sku_identifier_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."bridge_seller_sku_identifier_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."bridge_seller_sku_identifier_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."dim_date" TO "anon";
GRANT ALL ON TABLE "public"."dim_date" TO "authenticated";
GRANT ALL ON TABLE "public"."dim_date" TO "service_role";



GRANT ALL ON TABLE "public"."dim_financial_category" TO "anon";
GRANT ALL ON TABLE "public"."dim_financial_category" TO "authenticated";
GRANT ALL ON TABLE "public"."dim_financial_category" TO "service_role";



GRANT ALL ON SEQUENCE "public"."dim_financial_category_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."dim_financial_category_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."dim_financial_category_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."dim_seller_sku" TO "anon";
GRANT ALL ON TABLE "public"."dim_seller_sku" TO "authenticated";
GRANT ALL ON TABLE "public"."dim_seller_sku" TO "service_role";



GRANT ALL ON SEQUENCE "public"."dim_seller_sku_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."dim_seller_sku_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."dim_seller_sku_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."fact_financial_transaction" TO "anon";
GRANT ALL ON TABLE "public"."fact_financial_transaction" TO "authenticated";
GRANT ALL ON TABLE "public"."fact_financial_transaction" TO "service_role";



GRANT ALL ON SEQUENCE "public"."fact_financial_transaction_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."fact_financial_transaction_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."fact_financial_transaction_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."fact_order" TO "anon";
GRANT ALL ON TABLE "public"."fact_order" TO "authenticated";
GRANT ALL ON TABLE "public"."fact_order" TO "service_role";



GRANT ALL ON SEQUENCE "public"."fact_order_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."fact_order_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."fact_order_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."fact_order_item" TO "anon";
GRANT ALL ON TABLE "public"."fact_order_item" TO "authenticated";
GRANT ALL ON TABLE "public"."fact_order_item" TO "service_role";



GRANT ALL ON SEQUENCE "public"."fact_order_item_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."fact_order_item_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."fact_order_item_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."financial_checkpoint" TO "anon";
GRANT ALL ON TABLE "public"."financial_checkpoint" TO "authenticated";
GRANT ALL ON TABLE "public"."financial_checkpoint" TO "service_role";



GRANT ALL ON TABLE "public"."financial_events" TO "anon";
GRANT ALL ON TABLE "public"."financial_events" TO "authenticated";
GRANT ALL ON TABLE "public"."financial_events" TO "service_role";



GRANT ALL ON TABLE "public"."integration_sources" TO "anon";
GRANT ALL ON TABLE "public"."integration_sources" TO "authenticated";
GRANT ALL ON TABLE "public"."integration_sources" TO "service_role";



GRANT ALL ON SEQUENCE "public"."integration_sources_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."integration_sources_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."integration_sources_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."login_attempts" TO "anon";
GRANT ALL ON TABLE "public"."login_attempts" TO "authenticated";
GRANT ALL ON TABLE "public"."login_attempts" TO "service_role";



GRANT ALL ON TABLE "public"."marketplace_accounts" TO "anon";
GRANT ALL ON TABLE "public"."marketplace_accounts" TO "authenticated";
GRANT ALL ON TABLE "public"."marketplace_accounts" TO "service_role";



GRANT ALL ON TABLE "public"."marketplace_fee_estimates" TO "anon";
GRANT ALL ON TABLE "public"."marketplace_fee_estimates" TO "authenticated";
GRANT ALL ON TABLE "public"."marketplace_fee_estimates" TO "service_role";



GRANT ALL ON TABLE "public"."ml_accounts" TO "service_role";



GRANT SELECT("id") ON TABLE "public"."ml_accounts" TO "authenticated";



GRANT SELECT("user_id") ON TABLE "public"."ml_accounts" TO "authenticated";



GRANT SELECT("ml_user_id") ON TABLE "public"."ml_accounts" TO "authenticated";



GRANT SELECT("nickname") ON TABLE "public"."ml_accounts" TO "authenticated";



GRANT SELECT("expires_at") ON TABLE "public"."ml_accounts" TO "authenticated";



GRANT SELECT("status") ON TABLE "public"."ml_accounts" TO "authenticated";



GRANT SELECT("last_sync_at") ON TABLE "public"."ml_accounts" TO "authenticated";



GRANT SELECT("created_at") ON TABLE "public"."ml_accounts" TO "authenticated";



GRANT ALL ON TABLE "public"."ml_oauth_states" TO "service_role";



GRANT ALL ON TABLE "public"."orders_amazon" TO "anon";
GRANT ALL ON TABLE "public"."orders_amazon" TO "authenticated";
GRANT ALL ON TABLE "public"."orders_amazon" TO "service_role";



GRANT ALL ON SEQUENCE "public"."orders_amazon_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."orders_amazon_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."orders_amazon_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."orders_checkpoint" TO "anon";
GRANT ALL ON TABLE "public"."orders_checkpoint" TO "authenticated";
GRANT ALL ON TABLE "public"."orders_checkpoint" TO "service_role";



GRANT ALL ON TABLE "public"."sellers" TO "anon";
GRANT ALL ON TABLE "public"."sellers" TO "authenticated";
GRANT ALL ON TABLE "public"."sellers" TO "service_role";



GRANT ALL ON TABLE "public"."stg_financial_transactions_amazon" TO "anon";
GRANT ALL ON TABLE "public"."stg_financial_transactions_amazon" TO "authenticated";
GRANT ALL ON TABLE "public"."stg_financial_transactions_amazon" TO "service_role";



GRANT ALL ON SEQUENCE "public"."stg_financial_transactions_amazon_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."stg_financial_transactions_amazon_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."stg_financial_transactions_amazon_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."stg_order_items_amazon" TO "anon";
GRANT ALL ON TABLE "public"."stg_order_items_amazon" TO "authenticated";
GRANT ALL ON TABLE "public"."stg_order_items_amazon" TO "service_role";



GRANT ALL ON SEQUENCE "public"."stg_order_items_amazon_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."stg_order_items_amazon_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."stg_order_items_amazon_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."stg_order_items_mercadolivre" TO "anon";
GRANT ALL ON TABLE "public"."stg_order_items_mercadolivre" TO "authenticated";
GRANT ALL ON TABLE "public"."stg_order_items_mercadolivre" TO "service_role";



GRANT ALL ON TABLE "public"."stg_orders_amazon" TO "anon";
GRANT ALL ON TABLE "public"."stg_orders_amazon" TO "authenticated";
GRANT ALL ON TABLE "public"."stg_orders_amazon" TO "service_role";



GRANT ALL ON SEQUENCE "public"."stg_orders_amazon_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."stg_orders_amazon_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."stg_orders_amazon_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."stg_orders_mercadolivre" TO "anon";
GRANT ALL ON TABLE "public"."stg_orders_mercadolivre" TO "authenticated";
GRANT ALL ON TABLE "public"."stg_orders_mercadolivre" TO "service_role";



GRANT ALL ON TABLE "public"."sync_checkpoint" TO "anon";
GRANT ALL ON TABLE "public"."sync_checkpoint" TO "authenticated";
GRANT ALL ON TABLE "public"."sync_checkpoint" TO "service_role";



GRANT ALL ON TABLE "public"."sync_checkpoint_orders" TO "anon";
GRANT ALL ON TABLE "public"."sync_checkpoint_orders" TO "authenticated";
GRANT ALL ON TABLE "public"."sync_checkpoint_orders" TO "service_role";



GRANT ALL ON TABLE "public"."sync_execution" TO "anon";
GRANT ALL ON TABLE "public"."sync_execution" TO "authenticated";
GRANT ALL ON TABLE "public"."sync_execution" TO "service_role";



GRANT ALL ON SEQUENCE "public"."sync_execution_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."sync_execution_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."sync_execution_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."vw_net_marketplace_estimated" TO "anon";
GRANT ALL ON TABLE "public"."vw_net_marketplace_estimated" TO "authenticated";
GRANT ALL ON TABLE "public"."vw_net_marketplace_estimated" TO "service_role";



GRANT ALL ON TABLE "public"."vw_gross_profit_consolidated" TO "anon";
GRANT ALL ON TABLE "public"."vw_gross_profit_consolidated" TO "authenticated";
GRANT ALL ON TABLE "public"."vw_gross_profit_consolidated" TO "service_role";



GRANT ALL ON TABLE "public"."vw_net_marketplace_estimated_v2" TO "anon";
GRANT ALL ON TABLE "public"."vw_net_marketplace_estimated_v2" TO "authenticated";
GRANT ALL ON TABLE "public"."vw_net_marketplace_estimated_v2" TO "service_role";



GRANT ALL ON TABLE "public"."vw_gross_profit_consolidated_v2" TO "anon";
GRANT ALL ON TABLE "public"."vw_gross_profit_consolidated_v2" TO "authenticated";
GRANT ALL ON TABLE "public"."vw_gross_profit_consolidated_v2" TO "service_role";



GRANT ALL ON TABLE "public"."vw_net_marketplace" TO "anon";
GRANT ALL ON TABLE "public"."vw_net_marketplace" TO "authenticated";
GRANT ALL ON TABLE "public"."vw_net_marketplace" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";































